package com.oms.common.config;

/**
 * Single source of truth for Kafka topic names.
 * All modules import from here to avoid string duplication.
 */
public final class KafkaTopics {

    private KafkaTopics() {}

    public static final String RFQ_EVENTS_V1   = "rfq.events.v1";
    public static final String QUOTE_EVENTS_V1  = "quote.events.v1";
    public static final String ORDER_EVENTS_V1  = "order.events.v1";

    // Dead letter topics follow a convention: <original>.DLT
    public static final String RFQ_EVENTS_DLT   = "rfq.events.v1.DLT";
    public static final String QUOTE_EVENTS_DLT = "quote.events.v1.DLT";
    public static final String ORDER_EVENTS_DLT = "order.events.v1.DLT";
}
