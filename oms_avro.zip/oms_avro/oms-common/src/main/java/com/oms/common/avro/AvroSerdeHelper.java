package com.oms.common.avro;

import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import io.confluent.kafka.serializers.KafkaAvroDeserializerConfig;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import io.confluent.kafka.serializers.KafkaAvroSerializerConfig;
import org.apache.avro.specific.SpecificRecord;

import java.util.Map;

/**
 * Thin factory helpers for Confluent Avro serializers.
 *
 * <p>The Confluent KafkaAvroSerializer writes a 5-byte magic prefix
 * (0x00 + 4-byte schema-id) followed by the Avro binary payload.
 * The corresponding KafkaAvroDeserializer reads and strips the prefix,
 * fetching the schema from the Schema Registry on first encounter.
 *
 * <p>Spring Kafka bean wiring supplies these via application.yml
 * {@code spring.kafka.producer.value-serializer} / {@code consumer.value-deserializer}.
 * This class is kept for test-level manual serializer construction.
 */
public final class AvroSerdeHelper {

    private AvroSerdeHelper() {}

    public static Map<String, Object> producerProps(String schemaRegistryUrl, String bootstrapServers) {
        return Map.of(
            "bootstrap.servers",                           bootstrapServers,
            KafkaAvroSerializerConfig.SCHEMA_REGISTRY_URL_CONFIG, schemaRegistryUrl,
            "key.serializer",   "org.apache.kafka.common.serialization.StringSerializer",
            "value.serializer", "io.confluent.kafka.serializers.KafkaAvroSerializer"
        );
    }

    public static Map<String, Object> consumerProps(String schemaRegistryUrl, String bootstrapServers, String groupId) {
        return Map.of(
            "bootstrap.servers",                                   bootstrapServers,
            KafkaAvroDeserializerConfig.SCHEMA_REGISTRY_URL_CONFIG, schemaRegistryUrl,
            KafkaAvroDeserializerConfig.SPECIFIC_AVRO_READER_CONFIG, true,
            "group.id",           groupId,
            "auto.offset.reset",  "earliest",
            "key.deserializer",   "org.apache.kafka.common.serialization.StringDeserializer",
            "value.deserializer", "io.confluent.kafka.serializers.KafkaAvroDeserializer"
        );
    }
}
