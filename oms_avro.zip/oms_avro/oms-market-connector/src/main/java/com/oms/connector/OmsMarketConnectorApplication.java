package com.oms.connector;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OmsMarketConnectorApplication {
    public static void main(String[] args) {
        SpringApplication.run(OmsMarketConnectorApplication.class, args);
    }
}
