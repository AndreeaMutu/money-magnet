package com.oms.connector.simulator;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Simulated FX price engine.
 *
 * <p>Maintains a mid-price per currency pair and applies a random walk on
 * each tick to simulate live market movement. The spread is a fixed number
 * of pips applied symmetrically around mid.
 *
 * <p>In a real system this would wrap a venue adapter (Bloomberg EMSX,
 * Reuters Elektron, FIX engine) translating market protocol into the
 * internal QuoteEvent model.
 */
@Slf4j
@Component
public class SimulatedPriceEngine {

    // Initial mid prices (approximate real-world values)
    private static final Map<String, BigDecimal> INITIAL_MIDS = Map.of(
        "EUR/USD", new BigDecimal("1.08500"),
        "GBP/USD", new BigDecimal("1.27300"),
        "USD/JPY", new BigDecimal("149.500"),
        "USD/CHF", new BigDecimal("0.88200"),
        "AUD/USD", new BigDecimal("0.65100")
    );

    // Spread per pair in pips (applied ±)
    private static final Map<String, BigDecimal> SPREADS = Map.of(
        "EUR/USD", new BigDecimal("0.00020"),
        "GBP/USD", new BigDecimal("0.00025"),
        "USD/JPY", new BigDecimal("0.030"),
        "USD/CHF", new BigDecimal("0.00020"),
        "AUD/USD", new BigDecimal("0.00025")
    );

    // Pip size per pair
    private static final Map<String, BigDecimal> PIP_SIZE = Map.of(
        "EUR/USD", new BigDecimal("0.00001"),
        "GBP/USD", new BigDecimal("0.00001"),
        "USD/JPY", new BigDecimal("0.001"),
        "USD/CHF", new BigDecimal("0.00001"),
        "AUD/USD", new BigDecimal("0.00001")
    );

    // Live mid-price state (thread-safe for concurrent quote requests)
    private final ConcurrentHashMap<String, BigDecimal> liveMids = new ConcurrentHashMap<>(INITIAL_MIDS);

    public record PriceQuote(
        String currencyPair,
        BigDecimal bidPrice,
        BigDecimal askPrice,
        BigDecimal midPrice
    ) {}

    /**
     * Generate a market quote for the given currency pair.
     * Applies a small random walk to the mid price before computing bid/ask.
     */
    public PriceQuote generateQuote(String currencyPair) {
        BigDecimal mid = tickMid(currencyPair);
        BigDecimal halfSpread = SPREADS.getOrDefault(currencyPair, new BigDecimal("0.00020"))
            .divide(BigDecimal.TWO, 10, RoundingMode.HALF_UP);

        BigDecimal bid = mid.subtract(halfSpread).setScale(5, RoundingMode.HALF_UP);
        BigDecimal ask = mid.add(halfSpread).setScale(5, RoundingMode.HALF_UP);

        log.debug("Simulated price {} bid={} ask={}", currencyPair, bid, ask);
        return new PriceQuote(currencyPair, bid, ask, mid);
    }

    // ----------------------------------------------------------------

    private BigDecimal tickMid(String currencyPair) {
        BigDecimal pip = PIP_SIZE.getOrDefault(currencyPair, new BigDecimal("0.00001"));
        // Random walk: ±0..3 pips per tick
        double randomPips = (ThreadLocalRandom.current().nextDouble() - 0.5) * 6;
        BigDecimal delta = pip.multiply(BigDecimal.valueOf(randomPips));

        return liveMids.compute(currencyPair, (pair, current) -> {
            if (current == null) current = new BigDecimal("1.00000");
            BigDecimal next = current.add(delta).setScale(5, RoundingMode.HALF_UP);
            // Keep price sane: never below 10% of initial mid
            BigDecimal floor = INITIAL_MIDS.getOrDefault(pair, BigDecimal.ONE)
                .multiply(new BigDecimal("0.9"));
            return next.max(floor);
        });
    }
}
