package com.oms.connector.consumer;

import com.oms.common.avro.RfqCreated;
import com.oms.common.config.KafkaTopics;
import com.oms.connector.producer.QuoteEventProducer;
import com.oms.connector.simulator.SimulatedPriceEngine;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.RetryableTopic;
import org.springframework.kafka.retrytopic.TopicSuffixingStrategy;
//import org.springframework.retry.annotation.Backoff;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;

/**
 * Simulated market connector: consumes RfqCreated Avro events, generates
 * a price via the simulated engine, and publishes a QuoteReceived event.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class RfqEventConsumer {

    private final SimulatedPriceEngine priceEngine;
    private final QuoteEventProducer   quoteProducer;

    @RetryableTopic(
        attempts = "3",
//        backoff = @Backoff(delay = 500, multiplier = 2.0),
        topicSuffixingStrategy = TopicSuffixingStrategy.SUFFIX_WITH_INDEX_VALUE,
        dltTopicSuffix = ".DLT",
        autoCreateTopics = "false"
    )
    @KafkaListener(
        topics = KafkaTopics.RFQ_EVENTS_V1,
        groupId = "${oms.connector.consumer.group-id:oms-market-connector}",
        containerFactory = "kafkaListenerContainerFactory"
    )
    public void onRfqEvent(Object record) {
        // Only act on RfqCreated; other subtypes (RfqExpired etc.) are no-ops here
        if (record instanceof RfqCreated created) {
            handleRfqCreated(created);
        }
    }

    private void handleRfqCreated(RfqCreated rfq) {
        log.info("Connector processing RFQ rfqId={} pair={} notional={}",
            rfq.getRfqId(), rfq.getCurrencyPair(), rfq.getNotional());

        simulateLatency();

        var price = priceEngine.generateQuote(rfq.getCurrencyPair());
        Instant quoteExpiry = Instant.now().plus(30, ChronoUnit.SECONDS);

        quoteProducer.publishQuoteReceived(
            UUID.randomUUID(),
            UUID.fromString(rfq.getRfqId()),
            rfq.getCorrelationId(),
            price.bidPrice(),
            price.askPrice(),
            rfq.getNotional(),
            rfq.getCurrencyPair(),
            quoteExpiry
        );
    }

    private void simulateLatency() {
        try {
            Thread.sleep(50 + (long) (Math.random() * 100));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
