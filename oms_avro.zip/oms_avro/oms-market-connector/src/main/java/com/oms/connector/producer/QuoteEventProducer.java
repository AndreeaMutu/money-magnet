package com.oms.connector.producer;

import com.oms.common.avro.QuoteExpired;
import com.oms.common.avro.QuoteReceived;
import com.oms.common.config.KafkaTopics;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.avro.specific.SpecificRecord;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

/**
 * Publishes QuoteEvents as Avro SpecificRecord to quote.events.v1.
 * The KafkaAvroSerializer registers the schema and prepends the 5-byte magic prefix.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class QuoteEventProducer {

    private final KafkaTemplate<String, SpecificRecord> kafkaTemplate;

    public void publishQuoteReceived(
        UUID quoteId, UUID rfqId, String correlationId,
        BigDecimal marketBidPrice, BigDecimal marketAskPrice,
        BigDecimal notional, String currencyPair, Instant expiresAt
    ) {
        QuoteReceived event = QuoteReceived.newBuilder()
            .setQuoteId(quoteId.toString())
            .setRfqId(rfqId.toString())
            .setCorrelationId(correlationId)
            .setOccurredAt(Instant.now())
            .setVersion(1)
            .setMarketBidPrice(marketBidPrice)
            .setMarketAskPrice(marketAskPrice)
            .setNotional(notional)
            .setCurrencyPair(currencyPair)
            .setExpiresAt(expiresAt)
            .build();

        kafkaTemplate.send(KafkaTopics.QUOTE_EVENTS_V1, quoteId.toString(), event);
        log.info("Published QUOTE_RECEIVED quoteId={} rfqId={} bid={} ask={}",
            quoteId, rfqId, marketBidPrice, marketAskPrice);
    }

    public void publishQuoteExpired(UUID quoteId, UUID rfqId, String correlationId, int version) {
        QuoteExpired event = QuoteExpired.newBuilder()
            .setQuoteId(quoteId.toString())
            .setRfqId(rfqId.toString())
            .setCorrelationId(correlationId)
            .setOccurredAt(Instant.now())
            .setVersion(version)
            .build();

        kafkaTemplate.send(KafkaTopics.QUOTE_EVENTS_V1, quoteId.toString(), event);
        log.info("Published QUOTE_EXPIRED quoteId={}", quoteId);
    }
}
