# OMS — Order Management System (Event-Driven, FX Spot PoC)

A production-grade event-driven trading OMS built with Java 21, Spring Boot 3.3,
Apache Kafka, PostgreSQL, and WebSocket (STOMP).

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                         CLIENT / BLOTTER UI                         │
│  REST POST /rfqs          REST POST /orders        WebSocket /ws    │
└──────────┬────────────────────────┬───────────────────────┬─────────┘
           │                        │                       │ STOMP subscribe
           ▼                        ▼                       │ /topic/quotes.user.{id}
┌─────────────────────┐  ┌─────────────────────┐           │ /topic/orders.desk.{id}
│    oms-command      │  │    oms-command       │           │
│  RfqController      │  │  OrderController     │           │
│  RfqCommandService  │  │  OrderCommandService │           │
│  [DB tx: entity +   │  │  [validates RFQ not  │           │
│   outbox row]       │  │   expired, writes    │           │
└────────┬────────────┘  │   entity + outbox]   │           │
         │               └──────────┬───────────┘           │
         │  OutboxRelayScheduler     │                       │
         │  polls every 200ms        │                       │
         ▼                          ▼                       │
┌─────────────────────────────────────────────────────────┐ │
│                      Apache Kafka                        │ │
│  rfq.events.v1   quote.events.v1   order.events.v1      │ │
│  (6 partitions)  (6 partitions)    (6 partitions)       │ │
│  *.DLT topics for dead-letter handling                   │ │
└──────┬─────────────────┬──────────────────┬─────────────┘ │
       │                 │                  │               │
       ▼                 │                  ▼               │
┌──────────────┐         │      ┌───────────────────────┐   │
│oms-market-   │         │      │     oms-query         │   │
│connector     │         │      │  QuoteEventConsumer   ├───┤
│              │         │      │  OrderEventConsumer   │   │
│ Consumes     │         └─────▶│                       │   │
│ rfq.events   │                │  Enriches with:       │   │
│              │                │  - RFQ details        │   │
│ Simulated    │                │  - Markup (refdata)   │   │
│ price engine │                │  - Account details    │   │
│ (random walk)│                │                       │   │
│              │                │  Persists read model  │   │
│ Publishes    │                │  (query schema)       │   │
│ quote.events ├───────────────▶│                       │   │
└──────────────┘                │  Pushes via WS ───────────┘
                                │                       │
                                │  BlotterController    │
                                │  GET /blotter/quotes  │
                                │  GET /blotter/orders  │
                                └───────────────────────┘

┌─────────────────────────────────────────────────────────┐
│                     PostgreSQL (single DB)               │
│   schema: command          │   schema: query             │
│   ├── rfq_versions         │   ├── quote_read_model      │
│   ├── order_versions       │   └── order_read_model      │
│   └── outbox_events        │                             │
└─────────────────────────────────────────────────────────┘
```

---

## Modules

| Module | Port | Responsibility |
|---|---|---|
| `oms-common` | — | Shared event contracts (sealed interfaces), Kafka topic constants |
| `oms-command` | 8080 | Write side: RFQ + Order creation, transactional outbox relay |
| `oms-query` | 8081 | Read side: event consumers, enrichment, WebSocket push, blotter API |
| `oms-market-connector` | 8082 | Simulated LP: consumes RFQ events, produces quote events |

---

## Key Design Decisions

### 1. Append-Only Versioned Write Model
Every state transition inserts a **new row** (`version + 1`). No `UPDATE` statements ever.
- Full audit trail for regulatory requirements
- No lost-update bugs under concurrent access
- The latest state = `WHERE version = MAX(version)` per entity

### 2. Transactional Outbox Pattern
Business entity + outbox event row written in **one database transaction**.
Guarantees: if the RFQ row is committed, the Kafka event *will* eventually be published.
No dual writes, no distributed transactions needed.

```
BEGIN TX
  INSERT INTO command.rfq_versions ...
  INSERT INTO command.outbox_events (status=PENDING) ...
COMMIT

[OutboxRelayScheduler - every 200ms]
  SELECT ... FOR UPDATE SKIP LOCKED  ← safe for multi-instance
  kafkaTemplate.send(...).get()      ← sync send
  UPDATE outbox_events SET status=PUBLISHED
```

### 3. SKIP LOCKED for Multi-Instance Safety
The outbox poller uses `SELECT ... FOR UPDATE SKIP LOCKED` so multiple
application instances never process the same batch. No coordinator needed.

### 4. Idempotency Keys
Both `/rfqs` and `/orders` require an `idempotencyKey`. Replaying the same
request returns the original response without creating duplicates. The key
has a `UNIQUE` constraint in the DB as the final safety net.

### 5. Sealed Interface Event Hierarchy
```java
public sealed interface RfqEvent permits RfqEvent.RfqCreated, RfqEvent.RfqExpired, ...
```
The `switch` in consumers is **exhaustive at compile time** — adding a new event
subtype causes a compilation error in every consumer, preventing silent omissions.

### 6. Non-Blocking Kafka Retries with DLT
`@RetryableTopic` provides exponential-backoff retry (1s → 2s → 4s → 8s)
without blocking the consumer thread. After exhaustion, the message goes to
the `.DLT` topic for operator inspection.

### 7. CQRS with Cross-Schema Reads
Command and query schemas live in the same Postgres instance but in separate schemas.
The command side reads `query.quote_read_model` via raw JDBC (not JPA) to fetch
the client price for order validation without coupling the JPA contexts.

---

## API Reference

### Command Side (port 8080)

#### Create RFQ
```
POST /api/v1/rfqs
Content-Type: application/json

{
  "idempotencyKey": "client-uuid-1",
  "userId":         "user-alice",
  "deskId":         "desk-fx-1",
  "instrumentId":   "EUR/USD-SPOT",
  "currencyPair":   "EUR/USD",
  "notional":       1000000,
  "currency":       "USD",
  "side":           "BUY",
  "ttlSeconds":     30
}
```

#### Create Order
```
POST /api/v1/orders
Content-Type: application/json

{
  "idempotencyKey": "order-uuid-1",
  "userId":         "user-alice",
  "rfqId":          "<uuid from rfq response>",
  "quoteId":        "<uuid from quote websocket>",
  "side":           "BUY"
}
```
Returns `409 Conflict` if the RFQ has expired.

### Query Side (port 8081)

#### Blotter — paginated quotes
```
GET /api/v1/blotter/quotes?userId=user-alice&page=0&size=50
GET /api/v1/blotter/quotes?deskId=desk-fx-1&page=0&size=50
```

#### Blotter — paginated orders
```
GET /api/v1/blotter/orders?userId=user-alice&page=0&size=50
GET /api/v1/blotter/orders?deskId=desk-fx-1&page=0&size=50
```

### WebSocket (port 8081)

Connect to `ws://localhost:8081/ws` (SockJS endpoint).

Subscribe to topics:
- `/topic/quotes.user.{userId}` — real-time quotes for user
- `/topic/quotes.desk.{deskId}` — all desk quotes (blotter)
- `/topic/orders.user.{userId}` — real-time order status
- `/topic/orders.desk.{deskId}` — all desk orders (blotter)

---

## Getting Started

### Prerequisites
- Docker & Docker Compose
- Java 21
- Maven 3.9+

### 1. Start infrastructure
```bash
docker-compose up -d
# Wait for Kafka topics to be created (kafka-init container exits 0)
docker-compose logs kafka-init
```

### 2. Build all modules
```bash
mvn clean package -DskipTests
```

### 3. Start services (in separate terminals)
```bash
# Command side
java -jar oms-command/target/oms-command-1.0.0-SNAPSHOT.jar

# Query side
java -jar oms-query/target/oms-query-1.0.0-SNAPSHOT.jar

# Market connector
java -jar oms-market-connector/target/oms-market-connector-1.0.0-SNAPSHOT.jar
```

### 4. Run tests
```bash
# Unit tests (no infra required)
mvn test -pl oms-command,oms-query

# Integration tests (requires Docker for Testcontainers)
mvn verify -pl oms-command
```

### 5. Observe Kafka
Open Kafka UI at http://localhost:8090

---

## Failure Mode Handling Summary

| Failure | Handling |
|---|---|
| Kafka broker down at publish | Outbox event stays PENDING; relay retries every 200ms |
| Kafka publish permanent failure | After 5 retries outbox record marked FAILED; retryFailed() reschedules with backoff |
| Consumer deserialization error | Thrown → @RetryableTopic retries → lands in DLT after exhaustion |
| Consumer processing error (transient) | @RetryableTopic exponential backoff (1s, 2s, 4s, 8s) |
| Consumer processing error (permanent) | Dead-letter topic (*.DLT) for operator replay |
| Duplicate RFQ/Order request | Idempotency key DB unique constraint + application-level check returns 200 |
| RFQ expired at order time | 409 Conflict returned; no order or outbox event written |
| Multi-instance outbox race | SKIP LOCKED ensures each batch is claimed by exactly one instance |
| App crash after DB commit, before Kafka send | Outbox record stays PENDING; recovered on restart |

---

## Production Hardening Checklist

- [ ] Replace simple WebSocket broker with RabbitMQ STOMP plugin (multi-instance WS)
- [ ] Add JWT authentication and filter WebSocket subscriptions by userId claim
- [ ] Add Micrometer metrics: outbox lag, consumer lag, quote-to-order latency
- [ ] Add Flyway migrations for schema evolution
- [ ] Replace `SimulatedPriceEngine` with real FIX/API venue adapter
- [ ] Implement DLT re-processing tooling (operator-triggered replay endpoint)
- [ ] Add RFQ/Quote expiry scheduler (scan for expired entities, publish lifecycle events)
- [ ] Partition Kafka topics by deskId for ordered processing per desk
- [ ] Add circuit breaker (Resilience4j) on reference data calls
- [ ] Configure Kafka topic retention and compaction policies
