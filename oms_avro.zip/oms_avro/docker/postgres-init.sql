-- docker/postgres-init.sql
-- Runs once on first container start.
-- Creates schemas and grants cross-schema read so command side can read query.quote_read_model
-- and query side can read command.rfq_versions.

CREATE SCHEMA IF NOT EXISTS command;
CREATE SCHEMA IF NOT EXISTS query;

-- Grant oms user full access to both schemas
GRANT ALL PRIVILEGES ON SCHEMA command TO oms;
GRANT ALL PRIVILEGES ON SCHEMA query   TO oms;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA command TO oms;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA query   TO oms;
ALTER DEFAULT PRIVILEGES IN SCHEMA command GRANT ALL ON TABLES TO oms;
ALTER DEFAULT PRIVILEGES IN SCHEMA query   GRANT ALL ON TABLES TO oms;
