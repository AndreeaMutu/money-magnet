package com.oms.query.quote;

import com.oms.common.avro.QuoteReceived;
import com.oms.query.config.WebSocketPublisher;
import com.oms.query.quote.consumer.QuoteEventConsumer;
import com.oms.query.quote.consumer.QuoteWebSocketMessage;
import com.oms.query.quote.repository.QuoteRepository;
import com.oms.query.refdata.ReferenceDataService;
import com.oms.query.refdata.RfqEnrichmentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class QuoteEventConsumerTest {

    @Mock QuoteRepository      quoteRepository;
    @Mock RfqEnrichmentService rfqEnrichment;
    @Mock ReferenceDataService referenceData;
    @Mock WebSocketPublisher   wsPublisher;

    QuoteEventConsumer consumer;

    UUID quoteId = UUID.randomUUID();
    UUID rfqId   = UUID.randomUUID();

    @BeforeEach
    void setUp() {
        consumer = new QuoteEventConsumer(quoteRepository, rfqEnrichment, referenceData, wsPublisher);
    }

    @Test
    void onQuoteEvent_quoteReceived_enrichesAndPersistsAndPublishesWs() {
        // Build a real Avro SpecificRecord — no JSON, no ObjectMapper
        QuoteReceived event = QuoteReceived.newBuilder()
            .setQuoteId(quoteId.toString())
            .setRfqId(rfqId.toString())
            .setCorrelationId("corr-1")
            .setOccurredAt(Instant.now())
            .setVersion(1)
            .setMarketBidPrice(new BigDecimal("1.08490"))
            .setMarketAskPrice(new BigDecimal("1.08510"))
            .setNotional(new BigDecimal("1000000"))
            .setCurrencyPair("EUR/USD")
            .setExpiresAt(Instant.now().plusSeconds(30))
            .build();

        when(rfqEnrichment.findLatestRfq(rfqId)).thenReturn(
            new RfqEnrichmentService.RfqDetails(rfqId, "user-alice", "desk-fx-1",
                "EUR/USD-SPOT", "EUR/USD",
                new BigDecimal("1000000"), "USD", "BUY",
                Instant.now().plusSeconds(30))
        );
        when(referenceData.getMarkup("EUR/USD")).thenReturn(new BigDecimal("0.0002"));
        when(referenceData.computeClientBidPrice(eq("EUR/USD"), any()))
            .thenReturn(new BigDecimal("1.08470"));
        when(referenceData.computeClientAskPrice(eq("EUR/USD"), any()))
            .thenReturn(new BigDecimal("1.08530"));

        consumer.onQuoteEvent(event);

        verify(quoteRepository).insert(
            eq(quoteId), eq(rfqId), eq(1),
            eq("user-alice"), eq("desk-fx-1"), eq("EUR/USD-SPOT"), eq("EUR/USD"),
            any(), any(), any(),
            eq(new BigDecimal("1.08470")), eq(new BigDecimal("1.08530")),
            eq(new BigDecimal("0.0002")), eq("RECEIVED"), any()
        );

        ArgumentCaptor<QuoteWebSocketMessage> msgCaptor =
            ArgumentCaptor.forClass(QuoteWebSocketMessage.class);
        verify(wsPublisher).publishQuoteToUser(eq("user-alice"), msgCaptor.capture());
        verify(wsPublisher).publishQuoteToDesk(eq("desk-fx-1"), any());

        QuoteWebSocketMessage msg = msgCaptor.getValue();
        assertThat(msg.userId()).isEqualTo("user-alice");
        assertThat(msg.clientAskPrice()).isEqualByComparingTo("1.08530");
        assertThat(msg.status()).isEqualTo("RECEIVED");
    }

    @Test
    void onQuoteEvent_unknownType_isIgnoredWithoutException() {
        // Should log a warning and not throw
        consumer.onQuoteEvent("unexpected-string-record");

        verifyNoInteractions(quoteRepository, rfqEnrichment, referenceData, wsPublisher);
    }
}
