package com.oms.query.refdata;

import lombok.RequiredArgsConstructor;
import org.jooq.DSLContext;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.NoSuchElementException;
import java.util.UUID;

//import static com.oms.command.generated.Tables.RFQ_VERSIONS;

/**
 * Reads RFQ context from the command schema for query-side enrichment.
 * Uses the command module's jOOQ-generated table reference directly —
 * same Postgres instance, cross-schema query, single DSLContext.
 */
@Component
@RequiredArgsConstructor
public class RfqEnrichmentService {

    private final DSLContext dsl;

    public record RfqDetails(
        UUID rfqId, String userId, String deskId,
        String instrumentId, String currencyPair,
        BigDecimal notional, String currency, String side, Instant expiresAt
    ) {}

    public RfqDetails findLatestRfq(UUID rfqId) {
//        return dsl.selectFrom(RFQ_VERSIONS)
//            .where(RFQ_VERSIONS.RFQ_ID.eq(rfqId))
//            .orderBy(RFQ_VERSIONS.VERSION.desc())
//            .limit(1)
//            .fetchOptional()
//            .map(r -> new RfqDetails(
//                r.getRfqId(), r.getUserId(), r.getDeskId(),
//                r.getInstrumentId(), r.getCurrencyPair(),
//                r.getNotional(), r.getCurrency(), r.getSide(),
//                r.getExpiresAt().toInstant()
//            ))
//            .orElseThrow(() -> new NoSuchElementException("RFQ not found for enrichment: " + rfqId));
        return null;
    }
}
