package com.oms.query.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

/**
 * Thin wrapper around SimpMessagingTemplate that enforces consistent
 * topic naming conventions across the query module.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class WebSocketPublisher {

    private final SimpMessagingTemplate messagingTemplate;

    // ---------------------------------------------------------------
    // Topic name builders
    // ---------------------------------------------------------------

    public static String quoteUserTopic(String userId) {
        return "/topic/quotes.user." + userId;
    }

    public static String quoteDeskTopic(String deskId) {
        return "/topic/quotes.desk." + deskId;
    }

    public static String orderUserTopic(String userId) {
        return "/topic/orders.user." + userId;
    }

    public static String orderDeskTopic(String deskId) {
        return "/topic/orders.desk." + deskId;
    }

    // ---------------------------------------------------------------
    // Publish methods
    // ---------------------------------------------------------------

    public void publishQuoteToUser(String userId, Object payload) {
        String topic = quoteUserTopic(userId);
        log.debug("WS push → {} payload={}", topic, payload);
        messagingTemplate.convertAndSend(topic, payload);
    }

    public void publishQuoteToDesk(String deskId, Object payload) {
        String topic = quoteDeskTopic(deskId);
        log.debug("WS push → {} payload={}", topic, payload);
        messagingTemplate.convertAndSend(topic, payload);
    }

    public void publishOrderToUser(String userId, Object payload) {
        String topic = orderUserTopic(userId);
        log.debug("WS push → {} payload={}", topic, payload);
        messagingTemplate.convertAndSend(topic, payload);
    }

    public void publishOrderToDesk(String deskId, Object payload) {
        String topic = orderDeskTopic(deskId);
        log.debug("WS push → {} payload={}", topic, payload);
        messagingTemplate.convertAndSend(topic, payload);
    }
}
