package com.oms.query.config;

import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import io.confluent.kafka.serializers.KafkaAvroDeserializerConfig;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.jooq.DSLContext;
import org.jooq.SQLDialect;
import org.jooq.impl.DataSourceConnectionProvider;
import org.jooq.impl.DefaultConfiguration;
import org.jooq.impl.DefaultDSLContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.TransactionAwareDataSourceProxy;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

/**
 * Query-module infrastructure.
 *
 * Kafka consumer is configured with {@link KafkaAvroDeserializer} and
 * {@code specific.avro.reader=true} so records are deserialised directly
 * into the generated {@link org.apache.avro.specific.SpecificRecord} subclasses
 * (e.g. {@link com.oms.common.avro.QuoteReceived}). The listener method
 * signature declares the exact type; no casting needed.
 */
@Configuration
public class QueryInfraConfig {

    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;

    @Value("${oms.kafka.schema-registry-url}")
    private String schemaRegistryUrl;

    @Value("${oms.kafka.consumer.group-id:oms-query}")
    private String groupId;

    @Bean @Primary
    public DSLContext dslContext(DataSource dataSource) {
        var proxy = new TransactionAwareDataSourceProxy(dataSource);
        var cp    = new DataSourceConnectionProvider(proxy);
        return new DefaultDSLContext(new DefaultConfiguration().set(cp).set(SQLDialect.POSTGRES));
    }

    @Bean
    public ConsumerFactory<String, Object> avroConsumerFactory() {
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,                bootstrapServers);
        props.put(ConsumerConfig.GROUP_ID_CONFIG,                         groupId);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,           StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,         KafkaAvroDeserializer.class);
        props.put(KafkaAvroDeserializerConfig.SCHEMA_REGISTRY_URL_CONFIG, schemaRegistryUrl);
        // Deserialise into generated SpecificRecord subclasses, not GenericRecord
        props.put(KafkaAvroDeserializerConfig.SPECIFIC_AVRO_READER_CONFIG, true);
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG,               false);
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,                "earliest");
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG,                 500);
        return new DefaultKafkaConsumerFactory<>(props);
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, Object> kafkaListenerContainerFactory(
            ConsumerFactory<String, Object> avroConsumerFactory) {
        var factory = new ConcurrentKafkaListenerContainerFactory<String, Object>();
        factory.setConsumerFactory(avroConsumerFactory);
        factory.setConcurrency(3);
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.RECORD);
        return factory;
    }
}
