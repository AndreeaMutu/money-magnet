package com.oms.query.refdata;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Simulated reference data service.
 *
 * In production this would call an internal reference data API or cache.
 * For this PoC it holds in-memory maps of instrument markups and account details.
 *
 * <p>Markup rule: clientPrice = marketPrice + markup (in price terms for FX spot).
 */
@Slf4j
@Service
public class ReferenceDataService {

    // Markup per currency pair in pip terms (e.g. 0.0002 = 2 pips for EUR/USD)
    private static final Map<String, BigDecimal> MARKUP_TABLE = Map.of(
        "EUR/USD", new BigDecimal("0.0002"),
        "GBP/USD", new BigDecimal("0.0003"),
        "USD/JPY", new BigDecimal("0.03"),
        "USD/CHF", new BigDecimal("0.0002"),
        "AUD/USD", new BigDecimal("0.0003")
    );

    private static final Map<String, AccountDetails> ACCOUNT_TABLE = Map.of(
        "desk-fx-1", new AccountDetails("desk-fx-1", "FX Spot Desk", "USD", "T_FX_1"),
        "desk-eq-1", new AccountDetails("desk-eq-1", "Equities Desk",  "USD", "T_EQ_1")
    );

    public record AccountDetails(
        String deskId,
        String deskName,
        String settlementCurrency,
        String tradingAccount
    ) {}

    /**
     * Returns the markup for a given currency pair.
     * Defaults to 0.0002 if the pair is not configured.
     */
    public BigDecimal getMarkup(String currencyPair) {
        return MARKUP_TABLE.getOrDefault(currencyPair, new BigDecimal("0.0002"));
    }

    /**
     * Computes the client-facing ask price: market ask + markup.
     * The bid price is symmetrically: market bid - markup.
     */
    public BigDecimal computeClientAskPrice(String currencyPair, BigDecimal marketAskPrice) {
        return marketAskPrice.add(getMarkup(currencyPair));
    }

    public BigDecimal computeClientBidPrice(String currencyPair, BigDecimal marketBidPrice) {
        return marketBidPrice.subtract(getMarkup(currencyPair));
    }

    public AccountDetails getAccountDetails(String deskId) {
        return ACCOUNT_TABLE.getOrDefault(deskId,
            new AccountDetails(deskId, "Unknown Desk", "USD", "UNKNOWN"));
    }
}
