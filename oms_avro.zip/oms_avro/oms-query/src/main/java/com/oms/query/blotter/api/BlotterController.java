package com.oms.query.blotter.api;

import com.oms.query.order.repository.OrderRepository;
import com.oms.query.order.repository.OrderRepository.OrderRow;
import com.oms.query.quote.repository.QuoteRepository;
import com.oms.query.quote.repository.QuoteRepository.QuoteRow;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Blotter REST API — paginated read access to the query read models.
 *
 * <p>Returns a custom {@link PageResponse} instead of Spring Data's Page,
 * since we no longer have Spring Data JPA and jOOQ handles pagination directly
 * with LIMIT/OFFSET plus a separate COUNT query.
 *
 * <pre>
 * GET /api/v1/blotter/quotes?userId=alice&page=0&size=50
 * GET /api/v1/blotter/quotes?deskId=desk-fx-1&page=0&size=50
 * GET /api/v1/blotter/orders?userId=alice&page=0&size=50
 * GET /api/v1/blotter/orders?deskId=desk-fx-1&page=0&size=50
 * </pre>
 */
@RestController
@RequestMapping("/api/v1/blotter")
@RequiredArgsConstructor
public class BlotterController {

    private static final int MAX_SIZE     = 200;
    private static final int DEFAULT_SIZE = 50;

    private final QuoteRepository quoteRepository;
    private final OrderRepository orderRepository;

    // ------------------------------------------------------------------
    // Quotes
    // ------------------------------------------------------------------

    @GetMapping("/quotes")
    public ResponseEntity<PageResponse<QuoteRow>> getQuotes(
        @RequestParam(required = false) String userId,
        @RequestParam(required = false) String deskId,
        @RequestParam(defaultValue = "0")  int page,
        @RequestParam(defaultValue = "50") int size
    ) {
        int safeSize   = clamp(size);
        int offset     = page * safeSize;

        if (userId != null) {
            long total = quoteRepository.countDistinctByUserId(userId);
            List<QuoteRow> rows = quoteRepository.findLatestByUserId(userId, safeSize, offset);
            return ResponseEntity.ok(PageResponse.of(rows, page, safeSize, total));
        }
        if (deskId != null) {
            long total = quoteRepository.countDistinctByDeskId(deskId);
            List<QuoteRow> rows = quoteRepository.findLatestByDeskId(deskId, safeSize, offset);
            return ResponseEntity.ok(PageResponse.of(rows, page, safeSize, total));
        }
        return ResponseEntity.badRequest().build();
    }

    // ------------------------------------------------------------------
    // Orders
    // ------------------------------------------------------------------

    @GetMapping("/orders")
    public ResponseEntity<PageResponse<OrderRow>> getOrders(
        @RequestParam(required = false) String userId,
        @RequestParam(required = false) String deskId,
        @RequestParam(defaultValue = "0")  int page,
        @RequestParam(defaultValue = "50") int size
    ) {
        int safeSize = clamp(size);
        int offset   = page * safeSize;

        if (userId != null) {
            long total = orderRepository.countDistinctByUserId(userId);
            List<OrderRow> rows = orderRepository.findLatestByUserId(userId, safeSize, offset);
            return ResponseEntity.ok(PageResponse.of(rows, page, safeSize, total));
        }
        if (deskId != null) {
            long total = orderRepository.countDistinctByDeskId(deskId);
            List<OrderRow> rows = orderRepository.findLatestByDeskId(deskId, safeSize, offset);
            return ResponseEntity.ok(PageResponse.of(rows, page, safeSize, total));
        }
        return ResponseEntity.badRequest().build();
    }

    // ------------------------------------------------------------------

    private int clamp(int n) { return Math.min(Math.max(1, n), MAX_SIZE); }

    /**
     * Minimal pagination envelope — replaces Spring Data's Page<T>.
     */
    public record PageResponse<T>(
        List<T> content,
        int     page,
        int     size,
        long    totalElements,
        int     totalPages,
        boolean first,
        boolean last
    ) {
        static <T> PageResponse<T> of(List<T> content, int page, int size, long total) {
            int totalPages = (int) Math.ceil((double) total / size);
            return new PageResponse<>(
                content, page, size, total, totalPages,
                page == 0, page >= totalPages - 1
            );
        }
    }
}
