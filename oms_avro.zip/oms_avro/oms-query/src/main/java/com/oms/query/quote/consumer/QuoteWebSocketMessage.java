package com.oms.query.quote.consumer;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

public record QuoteWebSocketMessage(
    UUID quoteId, UUID rfqId, int version,
    String userId, String deskId, String currencyPair,
    BigDecimal notional,
    BigDecimal marketBidPrice, BigDecimal marketAskPrice,
    BigDecimal clientBidPrice, BigDecimal clientAskPrice,
    BigDecimal markup, String status, Instant expiresAt, Instant updatedAt
) {}
