package com.oms.query.quote.consumer;

import com.oms.common.avro.QuoteAccepted;
import com.oms.common.avro.QuoteExpired;
import com.oms.common.avro.QuoteReceived;
import com.oms.common.avro.QuoteRejected;
import com.oms.common.config.KafkaTopics;
import com.oms.query.config.WebSocketPublisher;
import com.oms.query.quote.repository.QuoteRepository;
import com.oms.query.refdata.ReferenceDataService;
import com.oms.query.refdata.RfqEnrichmentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.avro.specific.SpecificRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.RetryableTopic;
import org.springframework.kafka.retrytopic.TopicSuffixingStrategy;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.UUID;

/**
 * Consumes QuoteEvents from quote.events.v1.
 *
 * <p>The Confluent {@link io.confluent.kafka.serializers.KafkaAvroDeserializer}
 * (configured with {@code specific.avro.reader=true}) deserialises each message
 * into the matching generated {@link SpecificRecord} subclass. The listener method
 * receives an {@link Object} and dispatches via {@code instanceof} pattern matching
 * — preserving the exhaustive switch semantics we had with the sealed interface
 * hierarchy, while being compatible with the Avro deserialization contract.
 *
 * <p>Idempotency: inserts use {@code ON CONFLICT DO NOTHING} on the
 * {@code (quote_id, version)} unique constraint, so replayed messages
 * from @RetryableTopic are silently skipped.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class QuoteEventConsumer {

    private final QuoteRepository      quoteRepository;
    private final RfqEnrichmentService rfqEnrichment;
    private final ReferenceDataService referenceData;
    private final WebSocketPublisher   wsPublisher;

    @RetryableTopic(
        attempts = "4",
//        backoff = @Backoff(delay = 1000, multiplier = 2.0, maxDelay = 30_000),
        topicSuffixingStrategy = TopicSuffixingStrategy.SUFFIX_WITH_INDEX_VALUE,
        dltTopicSuffix = ".DLT",
        autoCreateTopics = "false"
    )
    @KafkaListener(
        topics = KafkaTopics.QUOTE_EVENTS_V1,
        groupId = "${oms.kafka.consumer.group-id:oms-query}",
        containerFactory = "kafkaListenerContainerFactory"
    )
    @Transactional
    public void onQuoteEvent(Object record) {
        switch (record) {
            case QuoteReceived r -> handleReceived(r);
            case QuoteExpired  r -> handleExpired(r);
            case QuoteAccepted r -> handleAccepted(r);
            case QuoteRejected r -> handleRejected(r);
            default -> log.warn("Unrecognised quote event type: {}", record.getClass().getName());
        }
    }

    // ------------------------------------------------------------------

    private void handleReceived(QuoteReceived event) {
        UUID quoteId = UUID.fromString(event.getQuoteId());
        UUID rfqId   = UUID.fromString(event.getRfqId());

        var rfq    = rfqEnrichment.findLatestRfq(rfqId);
        var markup = referenceData.getMarkup(event.getCurrencyPair());
        var cBid   = referenceData.computeClientBidPrice(event.getCurrencyPair(), event.getMarketBidPrice());
        var cAsk   = referenceData.computeClientAskPrice(event.getCurrencyPair(), event.getMarketAskPrice());

        quoteRepository.insert(
            quoteId, rfqId, event.getVersion(),
            rfq.userId(), rfq.deskId(), rfq.instrumentId(), event.getCurrencyPair(),
            event.getNotional(),
            event.getMarketBidPrice(), event.getMarketAskPrice(),
            cBid, cAsk, markup,
            "RECEIVED", event.getExpiresAt()
        );

        var msg = buildWebSocketMessage(quoteId, rfqId, event.getVersion(),
            rfq.userId(), rfq.deskId(), event.getCurrencyPair(), event.getNotional(),
            event.getMarketBidPrice(), event.getMarketAskPrice(), cBid, cAsk, markup,
            "RECEIVED", event.getExpiresAt());

        wsPublisher.publishQuoteToUser(rfq.userId(), msg);
        wsPublisher.publishQuoteToDesk(rfq.deskId(), msg);
        log.info("Quote received quoteId={} rfqId={} clientAsk={}", quoteId, rfqId, cAsk);
    }

    private void handleExpired(QuoteExpired event) {
        updateAndPush(UUID.fromString(event.getQuoteId()), event.getVersion(), "EXPIRED");
    }

    private void handleAccepted(QuoteAccepted event) {
        updateAndPush(UUID.fromString(event.getQuoteId()), event.getVersion(), "ACCEPTED");
    }

    private void handleRejected(QuoteRejected event) {
        updateAndPush(UUID.fromString(event.getQuoteId()), event.getVersion(), "REJECTED");
    }

    private void updateAndPush(UUID quoteId, int newVersion, String status) {
        quoteRepository.findLatestByQuoteId(quoteId).ifPresentOrElse(latest -> {
            quoteRepository.insert(
                latest.quoteId(), latest.rfqId(), newVersion,
                latest.userId(), latest.deskId(), latest.instrumentId(), latest.currencyPair(),
                latest.notional(),
                latest.marketBidPrice(), latest.marketAskPrice(),
                latest.clientBidPrice(), latest.clientAskPrice(),
                latest.markup(), status, latest.expiresAt()
            );
            var msg = buildWebSocketMessage(
                latest.quoteId(), latest.rfqId(), newVersion,
                latest.userId(), latest.deskId(), latest.currencyPair(), latest.notional(),
                latest.marketBidPrice(), latest.marketAskPrice(),
                latest.clientBidPrice(), latest.clientAskPrice(),
                latest.markup(), status, latest.expiresAt());
            wsPublisher.publishQuoteToUser(latest.userId(), msg);
            wsPublisher.publishQuoteToDesk(latest.deskId(), msg);
            log.info("Quote {} quoteId={}", status, quoteId);
        }, () -> log.warn("Quote not found for status update quoteId={}", quoteId));
    }

    private QuoteWebSocketMessage buildWebSocketMessage(
            UUID quoteId, UUID rfqId, int version,
            String userId, String deskId, String currencyPair,
            java.math.BigDecimal notional,
            java.math.BigDecimal mBid, java.math.BigDecimal mAsk,
            java.math.BigDecimal cBid, java.math.BigDecimal cAsk,
            java.math.BigDecimal markup, String status, Instant expiresAt) {
        return new QuoteWebSocketMessage(
            quoteId, rfqId, version, userId, deskId, currencyPair,
            notional, mBid, mAsk, cBid, cAsk, markup, status, expiresAt, Instant.now());
    }
}
