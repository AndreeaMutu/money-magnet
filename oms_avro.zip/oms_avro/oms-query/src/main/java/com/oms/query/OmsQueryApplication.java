package com.oms.query;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OmsQueryApplication {
    public static void main(String[] args) {
        SpringApplication.run(OmsQueryApplication.class, args);
    }
}
