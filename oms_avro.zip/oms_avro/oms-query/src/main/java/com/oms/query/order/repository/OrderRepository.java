package com.oms.query.order.repository;

import lombok.RequiredArgsConstructor;
import org.jooq.DSLContext;
import org.jooq.Record;
import org.jooq.impl.DSL;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static com.oms.query.generated.Tables.ORDER_READ_MODEL;

/**
 * jOOQ repository for order read-model rows.
 *
 * <p>Blotter queries use ROW_NUMBER() OVER (PARTITION BY order_id ORDER BY version DESC)
 * to select only the latest version per orderId — a single table scan with a window
 * function is faster than a correlated subquery at blotter scale.
 */
@Repository
@RequiredArgsConstructor
public class OrderRepository {

    private final DSLContext dsl;

    public void insert(
        UUID orderId, UUID rfqId, UUID quoteId, int version,
        String userId, String deskId, String instrumentId,
        String currencyPair, BigDecimal notional, String currency,
        String side, BigDecimal clientPrice,
        String deskName, String tradingAccount, String settlementCurrency,
        String status
    ) {
        dsl.insertInto(ORDER_READ_MODEL)
            .set(ORDER_READ_MODEL.ORDER_ID,            orderId)
            .set(ORDER_READ_MODEL.RFQ_ID,              rfqId)
            .set(ORDER_READ_MODEL.QUOTE_ID,            quoteId)
            .set(ORDER_READ_MODEL.VERSION,             version)
            .set(ORDER_READ_MODEL.USER_ID,             userId)
            .set(ORDER_READ_MODEL.DESK_ID,             deskId)
            .set(ORDER_READ_MODEL.INSTRUMENT_ID,       instrumentId)
            .set(ORDER_READ_MODEL.CURRENCY_PAIR,       currencyPair)
            .set(ORDER_READ_MODEL.NOTIONAL,            notional)
            .set(ORDER_READ_MODEL.CURRENCY,            currency)
            .set(ORDER_READ_MODEL.SIDE,                side)
            .set(ORDER_READ_MODEL.CLIENT_PRICE,        clientPrice)
            .set(ORDER_READ_MODEL.DESK_NAME,           deskName)
            .set(ORDER_READ_MODEL.TRADING_ACCOUNT,     tradingAccount)
            .set(ORDER_READ_MODEL.SETTLEMENT_CURRENCY, settlementCurrency)
            .set(ORDER_READ_MODEL.STATUS,              status)
            .onConflictDoNothing()   // idempotency: skip duplicate (orderId, version) pairs
            .execute();
    }

    public Optional<OrderRow> findLatestByOrderId(UUID orderId) {
        return dsl.selectFrom(ORDER_READ_MODEL)
            .where(ORDER_READ_MODEL.ORDER_ID.eq(orderId))
            .orderBy(ORDER_READ_MODEL.VERSION.desc())
            .limit(1)
            .fetchOptional()
            .map(this::toRow);
    }

    /** Blotter: latest version per orderId for a user, paginated. */
    public List<OrderRow> findLatestByUserId(String userId, int limit, int offset) {
        var rn = DSL.rowNumber()
            .over(DSL.partitionBy(ORDER_READ_MODEL.ORDER_ID)
                     .orderBy(ORDER_READ_MODEL.VERSION.desc()))
            .as("rn");

        var sub = dsl.select(ORDER_READ_MODEL.asterisk(), rn)
            .from(ORDER_READ_MODEL)
            .where(ORDER_READ_MODEL.USER_ID.eq(userId))
            .asTable("t");

        return dsl.selectFrom(sub)
            .where(DSL.field("rn", Integer.class).eq(1))
            .orderBy(DSL.field(sub.field("created_at")).desc())
            .limit(limit).offset(offset)
            .fetch()
            .map(r -> toRow(r));
    }

    /** Blotter: latest version per orderId for a desk, paginated. */
    public List<OrderRow> findLatestByDeskId(String deskId, int limit, int offset) {
        var rn = DSL.rowNumber()
            .over(DSL.partitionBy(ORDER_READ_MODEL.ORDER_ID)
                     .orderBy(ORDER_READ_MODEL.VERSION.desc()))
            .as("rn");

        var sub = dsl.select(ORDER_READ_MODEL.asterisk(), rn)
            .from(ORDER_READ_MODEL)
            .where(ORDER_READ_MODEL.DESK_ID.eq(deskId))
            .asTable("t");

        return dsl.selectFrom(sub)
            .where(DSL.field("rn", Integer.class).eq(1))
            .orderBy(DSL.field(sub.field("created_at")).desc())
            .limit(limit).offset(offset)
            .fetch()
            .map(r -> toRow(r));
    }

    public long countDistinctByUserId(String userId) {
        return dsl.selectCount().from(
            dsl.selectDistinct(ORDER_READ_MODEL.ORDER_ID)
               .from(ORDER_READ_MODEL)
               .where(ORDER_READ_MODEL.USER_ID.eq(userId))
        ).fetchOne(0, Long.class);
    }

    public long countDistinctByDeskId(String deskId) {
        return dsl.selectCount().from(
            dsl.selectDistinct(ORDER_READ_MODEL.ORDER_ID)
               .from(ORDER_READ_MODEL)
               .where(ORDER_READ_MODEL.DESK_ID.eq(deskId))
        ).fetchOne(0, Long.class);
    }

    // ------------------------------------------------------------------

    public record OrderRow(
        UUID orderId, UUID rfqId, UUID quoteId, int version,
        String userId, String deskId, String instrumentId,
        String currencyPair, BigDecimal notional, String currency,
        String side, BigDecimal clientPrice,
        String deskName, String tradingAccount, String settlementCurrency,
        String status, Instant createdAt
    ) {}

    private OrderRow toRow(Record r) {
        return new OrderRow(
            r.get(ORDER_READ_MODEL.ORDER_ID),
            r.get(ORDER_READ_MODEL.RFQ_ID),
            r.get(ORDER_READ_MODEL.QUOTE_ID),
            r.get(ORDER_READ_MODEL.VERSION),
            r.get(ORDER_READ_MODEL.USER_ID),
            r.get(ORDER_READ_MODEL.DESK_ID),
            r.get(ORDER_READ_MODEL.INSTRUMENT_ID),
            r.get(ORDER_READ_MODEL.CURRENCY_PAIR),
            r.get(ORDER_READ_MODEL.NOTIONAL),
            r.get(ORDER_READ_MODEL.CURRENCY),
            r.get(ORDER_READ_MODEL.SIDE),
            r.get(ORDER_READ_MODEL.CLIENT_PRICE),
            r.get(ORDER_READ_MODEL.DESK_NAME),
            r.get(ORDER_READ_MODEL.TRADING_ACCOUNT),
            r.get(ORDER_READ_MODEL.SETTLEMENT_CURRENCY),
            r.get(ORDER_READ_MODEL.STATUS),
            r.get(ORDER_READ_MODEL.CREATED_AT).toInstant()
        );
    }
}
