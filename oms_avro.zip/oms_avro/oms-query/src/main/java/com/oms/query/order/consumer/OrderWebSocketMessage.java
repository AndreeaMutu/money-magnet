package com.oms.query.order.consumer;

import com.oms.query.order.repository.OrderRepository.OrderRow;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

public record OrderWebSocketMessage(
    UUID orderId, UUID rfqId, UUID quoteId, int version,
    String userId, String deskId, String deskName, String tradingAccount,
    String instrumentId, String currencyPair,
    BigDecimal notional, String currency, String side,
    BigDecimal clientPrice, String status, Instant updatedAt
) {
    public static OrderWebSocketMessage from(OrderRow r) {
        return new OrderWebSocketMessage(
            r.orderId(), r.rfqId(), r.quoteId(), r.version(),
            r.userId(), r.deskId(), r.deskName(), r.tradingAccount(),
            r.instrumentId(), r.currencyPair(),
            r.notional(), r.currency(), r.side(),
            r.clientPrice(), r.status(), r.createdAt()
        );
    }
}
