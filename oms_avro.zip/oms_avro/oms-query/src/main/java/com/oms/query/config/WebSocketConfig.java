package com.oms.query.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

/**
 * STOMP over WebSocket configuration.
 *
 * <p>Topic conventions:
 * <ul>
 *   <li>{@code /topic/quotes.user.{userId}}  — real-time quote updates for a specific user</li>
 *   <li>{@code /topic/quotes.desk.{deskId}}  — all quotes flowing through a desk (blotter)</li>
 *   <li>{@code /topic/orders.user.{userId}}  — real-time order updates for a specific user</li>
 *   <li>{@code /topic/orders.desk.{deskId}}  — all orders for a desk (blotter)</li>
 * </ul>
 *
 * <p>Clients subscribe using standard STOMP SUBSCRIBE frames.
 * The simple in-memory broker is sufficient for a PoC; swap to a full broker
 * (RabbitMQ STOMP plugin) for multi-instance production deployments.
 */
@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        // Simple in-memory broker for /topic destinations
        registry.enableSimpleBroker("/topic");
        // Application-level prefix for @MessageMapping methods (if added later)
        registry.setApplicationDestinationPrefixes("/app");
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/ws")
            .setAllowedOriginPatterns("*")  // Lock down in production
            .withSockJS();                  // SockJS fallback for non-WS environments
    }
}
