package com.oms.query.order.consumer;

import com.oms.common.avro.*;
import com.oms.common.config.KafkaTopics;
import com.oms.query.config.WebSocketPublisher;
import com.oms.query.order.repository.OrderRepository;
import com.oms.query.refdata.ReferenceDataService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.RetryableTopic;
import org.springframework.kafka.retrytopic.TopicSuffixingStrategy;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.UUID;

/**
 * Consumes OrderEvents from order.events.v1.
 * Avro-deserialised by the Confluent KafkaAvroDeserializer (specific reader mode).
 * Idempotent via ON CONFLICT DO NOTHING on (order_id, version).
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class OrderEventConsumer {

    private final OrderRepository      orderRepository;
    private final ReferenceDataService referenceData;
    private final WebSocketPublisher   wsPublisher;

    @RetryableTopic(
        attempts = "4",
//        backoff = @Backoff(delay = 1000, multiplier = 2.0, maxDelay = 30_000),
        topicSuffixingStrategy = TopicSuffixingStrategy.SUFFIX_WITH_INDEX_VALUE,
        dltTopicSuffix = ".DLT",
        autoCreateTopics = "false"
    )
    @KafkaListener(
        topics = KafkaTopics.ORDER_EVENTS_V1,
        groupId = "${oms.kafka.consumer.group-id:oms-query}",
        containerFactory = "kafkaListenerContainerFactory"
    )
    @Transactional
    public void onOrderEvent(Object record) {
        switch (record) {
            case OrderCreated   r -> handleCreated(r);
            case OrderSubmitted r -> handleSubmitted(r);
            case OrderFilled    r -> handleFilled(r);
            case OrderRejected  r -> handleRejected(r);
            case OrderCancelled r -> handleCancelled(r);
            default -> log.warn("Unrecognised order event type: {}", record.getClass().getName());
        }
    }

    // ------------------------------------------------------------------

    private void handleCreated(OrderCreated event) {
        UUID orderId = UUID.fromString(event.getOrderId());
        var account  = referenceData.getAccountDetails(event.getDeskId());

        orderRepository.insert(
            orderId,
            UUID.fromString(event.getRfqId()),
            UUID.fromString(event.getQuoteId()),
            event.getVersion(),
            event.getUserId(), event.getDeskId(), event.getInstrumentId(),
            event.getCurrencyPair(), event.getNotional(), event.getCurrency(),
            event.getSide().name(), event.getClientPrice(),
            account.deskName(), account.tradingAccount(), account.settlementCurrency(),
            "PENDING"
        );

        pushOrder(orderId, event.getUserId(), event.getDeskId());
        log.info("Order read-model created orderId={}", orderId);
    }

    private void handleSubmitted(OrderSubmitted event) {
        updateAndPush(UUID.fromString(event.getOrderId()), event.getVersion(), "SUBMITTED");
    }

    private void handleFilled(OrderFilled event) {
        updateAndPush(UUID.fromString(event.getOrderId()), event.getVersion(), "FILLED");
    }

    private void handleRejected(OrderRejected event) {
        updateAndPush(UUID.fromString(event.getOrderId()), event.getVersion(), "REJECTED");
    }

    private void handleCancelled(OrderCancelled event) {
        updateAndPush(UUID.fromString(event.getOrderId()), event.getVersion(), "CANCELLED");
    }

    private void updateAndPush(UUID orderId, int newVersion, String status) {
        orderRepository.findLatestByOrderId(orderId).ifPresentOrElse(latest -> {
            orderRepository.insert(
                latest.orderId(), latest.rfqId(), latest.quoteId(), newVersion,
                latest.userId(), latest.deskId(), latest.instrumentId(),
                latest.currencyPair(), latest.notional(), latest.currency(),
                latest.side(), latest.clientPrice(),
                latest.deskName(), latest.tradingAccount(), latest.settlementCurrency(),
                status
            );
            pushOrder(orderId, latest.userId(), latest.deskId());
            log.info("Order {} orderId={}", status, orderId);
        }, () -> log.warn("Order not found for status update orderId={}", orderId));
    }

    private void pushOrder(UUID orderId, String userId, String deskId) {
        orderRepository.findLatestByOrderId(orderId).ifPresent(row -> {
            var msg = OrderWebSocketMessage.from(row);
            wsPublisher.publishOrderToUser(userId, msg);
            wsPublisher.publishOrderToDesk(deskId, msg);
        });
    }
}
