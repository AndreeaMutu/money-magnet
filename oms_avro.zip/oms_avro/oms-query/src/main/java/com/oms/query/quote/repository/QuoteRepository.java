package com.oms.query.quote.repository;

import lombok.RequiredArgsConstructor;
import org.jooq.DSLContext;
import org.jooq.Record;
import org.jooq.impl.DSL;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static com.oms.query.generated.Tables.QUOTE_READ_MODEL;

/**
 * jOOQ repository for quote read-model rows.
 *
 * <p>The blotter queries use a window function to select only the latest version
 * per quoteId, avoiding a correlated subquery and giving the planner a better
 * chance to use the composite index on (quote_id, version DESC):
 *
 * <pre>
 *   SELECT * FROM (
 *     SELECT *, ROW_NUMBER() OVER (PARTITION BY quote_id ORDER BY version DESC) rn
 *     FROM query.quote_read_model
 *     WHERE user_id = ?
 *   ) t WHERE rn = 1
 *   ORDER BY created_at DESC
 *   LIMIT ? OFFSET ?
 * </pre>
 */
@Repository
@RequiredArgsConstructor
public class QuoteRepository {

    private final DSLContext dsl;

    public void insert(
        UUID quoteId, UUID rfqId, int version,
        String userId, String deskId, String instrumentId, String currencyPair,
        BigDecimal notional,
        BigDecimal marketBid, BigDecimal marketAsk,
        BigDecimal clientBid, BigDecimal clientAsk,
        BigDecimal markup, String status, Instant expiresAt
    ) {
        dsl.insertInto(QUOTE_READ_MODEL)
            .set(QUOTE_READ_MODEL.QUOTE_ID,          quoteId)
            .set(QUOTE_READ_MODEL.RFQ_ID,            rfqId)
            .set(QUOTE_READ_MODEL.VERSION,           version)
            .set(QUOTE_READ_MODEL.USER_ID,           userId)
            .set(QUOTE_READ_MODEL.DESK_ID,           deskId)
            .set(QUOTE_READ_MODEL.INSTRUMENT_ID,     instrumentId)
            .set(QUOTE_READ_MODEL.CURRENCY_PAIR,     currencyPair)
            .set(QUOTE_READ_MODEL.NOTIONAL,          notional)
            .set(QUOTE_READ_MODEL.MARKET_BID_PRICE,  marketBid)
            .set(QUOTE_READ_MODEL.MARKET_ASK_PRICE,  marketAsk)
            .set(QUOTE_READ_MODEL.CLIENT_BID_PRICE,  clientBid)
            .set(QUOTE_READ_MODEL.CLIENT_ASK_PRICE,  clientAsk)
            .set(QUOTE_READ_MODEL.MARKUP,            markup)
            .set(QUOTE_READ_MODEL.STATUS,            status)
            .set(QUOTE_READ_MODEL.EXPIRES_AT,        OffsetDateTime.ofInstant(expiresAt, ZoneOffset.UTC))
            .onConflictDoNothing()   // idempotency: skip duplicate (quoteId, version) pairs
            .execute();
    }

    public Optional<QuoteRow> findLatestByQuoteId(UUID quoteId) {
        return dsl.selectFrom(QUOTE_READ_MODEL)
            .where(QUOTE_READ_MODEL.QUOTE_ID.eq(quoteId))
            .orderBy(QUOTE_READ_MODEL.VERSION.desc())
            .limit(1)
            .fetchOptional()
            .map(this::toRow);
    }

    /** Blotter: latest version per quoteId for a user, paginated. */
    public List<QuoteRow> findLatestByUserId(String userId, int limit, int offset) {
        var rn = DSL.rowNumber()
            .over(DSL.partitionBy(QUOTE_READ_MODEL.QUOTE_ID)
                     .orderBy(QUOTE_READ_MODEL.VERSION.desc()))
            .as("rn");

        var sub = dsl.select(QUOTE_READ_MODEL.asterisk(), rn)
            .from(QUOTE_READ_MODEL)
            .where(QUOTE_READ_MODEL.USER_ID.eq(userId))
            .asTable("t");

        return dsl.selectFrom(sub)
            .where(DSL.field("rn", Integer.class).eq(1))
            .orderBy(DSL.field(sub.field("created_at")).desc())
            .limit(limit).offset(offset)
            .fetch()
            .map(r -> toRow(r));
    }

    /** Blotter: latest version per quoteId for a desk, paginated. */
    public List<QuoteRow> findLatestByDeskId(String deskId, int limit, int offset) {
        var rn = DSL.rowNumber()
            .over(DSL.partitionBy(QUOTE_READ_MODEL.QUOTE_ID)
                     .orderBy(QUOTE_READ_MODEL.VERSION.desc()))
            .as("rn");

        var sub = dsl.select(QUOTE_READ_MODEL.asterisk(), rn)
            .from(QUOTE_READ_MODEL)
            .where(QUOTE_READ_MODEL.DESK_ID.eq(deskId))
            .asTable("t");

        return dsl.selectFrom(sub)
            .where(DSL.field("rn", Integer.class).eq(1))
            .orderBy(DSL.field(sub.field("created_at")).desc())
            .limit(limit).offset(offset)
            .fetch()
            .map(r -> toRow(r));
    }

    public long countDistinctByUserId(String userId) {
        return dsl.selectCount().from(
            dsl.selectDistinct(QUOTE_READ_MODEL.QUOTE_ID)
               .from(QUOTE_READ_MODEL)
               .where(QUOTE_READ_MODEL.USER_ID.eq(userId))
        ).fetchOne(0, Long.class);
    }

    public long countDistinctByDeskId(String deskId) {
        return dsl.selectCount().from(
            dsl.selectDistinct(QUOTE_READ_MODEL.QUOTE_ID)
               .from(QUOTE_READ_MODEL)
               .where(QUOTE_READ_MODEL.DESK_ID.eq(deskId))
        ).fetchOne(0, Long.class);
    }

    // ------------------------------------------------------------------

    public record QuoteRow(
        UUID quoteId, UUID rfqId, int version,
        String userId, String deskId, String instrumentId, String currencyPair,
        BigDecimal notional,
        BigDecimal marketBidPrice, BigDecimal marketAskPrice,
        BigDecimal clientBidPrice, BigDecimal clientAskPrice,
        BigDecimal markup, String status, Instant expiresAt, Instant createdAt
    ) {}

    private QuoteRow toRow(Record r) {
        return new QuoteRow(
            r.get(QUOTE_READ_MODEL.QUOTE_ID),
            r.get(QUOTE_READ_MODEL.RFQ_ID),
            r.get(QUOTE_READ_MODEL.VERSION),
            r.get(QUOTE_READ_MODEL.USER_ID),
            r.get(QUOTE_READ_MODEL.DESK_ID),
            r.get(QUOTE_READ_MODEL.INSTRUMENT_ID),
            r.get(QUOTE_READ_MODEL.CURRENCY_PAIR),
            r.get(QUOTE_READ_MODEL.NOTIONAL),
            r.get(QUOTE_READ_MODEL.MARKET_BID_PRICE),
            r.get(QUOTE_READ_MODEL.MARKET_ASK_PRICE),
            r.get(QUOTE_READ_MODEL.CLIENT_BID_PRICE),
            r.get(QUOTE_READ_MODEL.CLIENT_ASK_PRICE),
            r.get(QUOTE_READ_MODEL.MARKUP),
            r.get(QUOTE_READ_MODEL.STATUS),
            r.get(QUOTE_READ_MODEL.EXPIRES_AT).toInstant(),
            r.get(QUOTE_READ_MODEL.CREATED_AT).toInstant()
        );
    }
}
