package com.oms.command.outbox.domain;

import org.apache.avro.specific.SpecificRecord;

import java.time.Instant;
import java.util.UUID;

/**
 * Outbox event value object.
 *
 * <p>No JPA annotations — this is a plain record used to carry data between
 * the application service and the jOOQ repository. The actual persistence
 * is done via jOOQ INSERT in {@link com.oms.command.outbox.infrastructure.OutboxRepository}.
 *
 * <p>The {@code payload} field holds the Avro-serialised bytes exactly as they
 * will be sent to Kafka — including the Confluent 5-byte magic prefix written
 * by {@link io.confluent.kafka.serializers.KafkaAvroSerializer}.  This means
 * the outbox relay can forward the bytes verbatim without re-serialising,
 * eliminating any schema mismatch between what was stored and what is sent.
 */
public record OutboxEvent(
    UUID    id,
    String  aggregateType,
    String  aggregateId,
    String  eventType,
    String  topic,
    String  kafkaKey,
    byte[]  payload,          // Avro binary (Confluent wire format)
    OutboxStatus status,
    Instant createdAt,
    Instant publishedAt,
    int     retryCount,
    String  lastError,
    long    rowVersion
) {
    /** Factory — creates a PENDING outbox event ready for INSERT. */
    public static OutboxEvent pending(
            String aggregateType,
            String aggregateId,
            String eventType,
            String topic,
            String kafkaKey,
            byte[] payload) {
        return new OutboxEvent(
            UUID.randomUUID(), aggregateType, aggregateId,
            eventType, topic, kafkaKey, payload,
            OutboxStatus.PENDING, Instant.now(),
            null, 0, null, 0L
        );
    }
}
