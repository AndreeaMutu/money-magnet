package com.oms.command.rfq.domain;

import com.oms.common.avro.Side;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

/**
 * RFQ write-model value object. No JPA annotations — persistence is handled
 * by {@link com.oms.command.rfq.infrastructure.RfqRepository} via jOOQ.
 *
 * <p>Uses a Java record for immutability; {@link #nextVersion} returns a new
 * instance rather than mutating state, keeping the domain model pure.
 */
public record RfqVersion(
    Long   id,            // DB surrogate key; null before INSERT
    UUID   rfqId,
    String idempotencyKey,
    int    version,
    String userId,
    String deskId,
    String instrumentId,
    String currencyPair,
    BigDecimal notional,
    String currency,
    Side   side,
    RfqStatus status,
    Instant expiresAt,
    Instant createdAt
) {
    public static RfqVersion createInitial(
        String idempotencyKey,
        String userId,
        String deskId,
        String instrumentId,
        String currencyPair,
        BigDecimal notional,
        String currency,
        Side side,
        Instant expiresAt
    ) {
        return new RfqVersion(
            null,
            UUID.randomUUID(),
            idempotencyKey,
            1,
            userId, deskId, instrumentId, currencyPair,
            notional, currency, side,
            RfqStatus.CREATED,
            expiresAt,
            Instant.now()
        );
    }

    public RfqVersion nextVersion(RfqStatus newStatus) {
        return new RfqVersion(
            null, rfqId, idempotencyKey, version + 1,
            userId, deskId, instrumentId, currencyPair,
            notional, currency, side, newStatus,
            expiresAt, Instant.now()
        );
    }

    public boolean isExpired() {
        return Instant.now().isAfter(expiresAt);
    }
}
