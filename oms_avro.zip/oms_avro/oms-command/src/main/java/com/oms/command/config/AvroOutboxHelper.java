package com.oms.command.config;

import io.confluent.kafka.serializers.KafkaAvroSerializer;
import io.confluent.kafka.serializers.KafkaAvroSerializerConfig;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import lombok.extern.slf4j.Slf4j;
import org.apache.avro.specific.SpecificRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Serialises an Avro {@link SpecificRecord} to the Confluent wire-format bytes
 * that will be stored in the outbox {@code payload} BYTEA column.
 *
 * <p>Why a dedicated serialiser instead of reusing KafkaTemplate?
 * The outbox pattern requires the serialised bytes to be written inside the
 * same database transaction as the domain entity.  KafkaTemplate operates
 * outside that transaction.  By pre-serialising here we store the bytes
 * atomically, and the relay forwards them verbatim without touching the
 * Schema Registry a second time.
 *
 * <p>The internal {@link KafkaAvroSerializer} is kept open for the lifetime of
 * the application and closed on shutdown to release the Schema Registry HTTP
 * connection pool cleanly.
 */
@Slf4j
@Component
public class AvroOutboxHelper {

    @Value("${oms.kafka.schema-registry-url}")
    private String schemaRegistryUrl;

    private KafkaAvroSerializer serializer;

    @PostConstruct
    void init() {
        serializer = new KafkaAvroSerializer();
        serializer.configure(
            Map.of(KafkaAvroSerializerConfig.SCHEMA_REGISTRY_URL_CONFIG, schemaRegistryUrl),
            false   // isKey = false
        );
        log.info("AvroOutboxHelper initialised with schemaRegistry={}", schemaRegistryUrl);
    }

    @PreDestroy
    void close() {
        if (serializer != null) serializer.close();
    }

    /**
     * Serialise {@code record} to Confluent wire-format bytes.
     * The topic is required by the Schema Registry subject-naming strategy
     * ({@code <topic>-value} by default).
     */
    public byte[] toBytes(String topic, SpecificRecord record) {
        return serializer.serialize(topic, record);
    }
}
