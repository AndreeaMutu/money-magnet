package com.oms.command.order.application;

/**
 * Thrown when an order references an RFQ that has passed its expiry timestamp.
 */
public class RfqExpiredException extends RuntimeException {
    public RfqExpiredException(java.util.UUID rfqId) {
        super("RFQ has expired and cannot be traded: rfqId=" + rfqId);
    }
}
