package com.oms.command.outbox.infrastructure;

import com.oms.command.outbox.domain.OutboxEvent;
import com.oms.command.outbox.domain.OutboxStatus;
import lombok.RequiredArgsConstructor;
import org.jooq.DSLContext;
import org.jooq.impl.DSL;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.UUID;

import static com.oms.command.generated.Tables.OUTBOX_EVENTS;

/**
 * jOOQ-based outbox repository.
 *
 * <p>Key design decisions:
 * <ul>
 *   <li>{@code insertPending} is called inside the same transaction as the domain entity INSERT,
 *       giving atomic write-or-rollback-both semantics.</li>
 *   <li>{@code fetchPendingSkipLocked} uses {@code FOR UPDATE SKIP LOCKED} —
 *       safe for concurrent pod deployments; no row is claimed by two pods.</li>
 *   <li>All UPDATE statements use optimistic row_version to detect races;
 *       a failed CAS is logged but not thrown — the relay will retry on next tick.</li>
 * </ul>
 */
@Repository
@RequiredArgsConstructor
public class OutboxRepository {

    private final DSLContext dsl;

    // ------------------------------------------------------------------
    // Write (called in same tx as domain entity)
    // ------------------------------------------------------------------

    @Transactional
    public void insertPending(OutboxEvent event) {
        dsl.insertInto(OUTBOX_EVENTS)
            .set(OUTBOX_EVENTS.ID,             event.id())
            .set(OUTBOX_EVENTS.AGGREGATE_TYPE, event.aggregateType())
            .set(OUTBOX_EVENTS.AGGREGATE_ID,   event.aggregateId())
            .set(OUTBOX_EVENTS.EVENT_TYPE,     event.eventType())
            .set(OUTBOX_EVENTS.TOPIC,          event.topic())
            .set(OUTBOX_EVENTS.KAFKA_KEY,      event.kafkaKey())
            .set(OUTBOX_EVENTS.PAYLOAD,        event.payload())
            .set(OUTBOX_EVENTS.STATUS,         OutboxStatus.PENDING.name())
            .set(OUTBOX_EVENTS.CREATED_AT,     toOffset(event.createdAt()))
            .set(OUTBOX_EVENTS.RETRY_COUNT,    0)
            .set(OUTBOX_EVENTS.ROW_VERSION,    0L)
            .execute();
    }

    // ------------------------------------------------------------------
    // Read — relay poller
    // ------------------------------------------------------------------

    /**
     * Fetch up to {@code batchSize} PENDING rows, locking them with SKIP LOCKED.
     * Only one instance in a cluster will see each row in a given tick.
     */
    public List<OutboxEvent> fetchPendingSkipLocked(int batchSize) {
        return dsl
            .selectFrom(OUTBOX_EVENTS)
            .where(OUTBOX_EVENTS.STATUS.eq(OutboxStatus.PENDING.name()))
            .orderBy(OUTBOX_EVENTS.CREATED_AT.asc())
            .limit(batchSize)
            .forUpdate().skipLocked()
            .fetch()
            .map(r -> new OutboxEvent(
                r.getId(),
                r.getAggregateType(),
                r.getAggregateId(),
                r.getEventType(),
                r.getTopic(),
                r.getKafkaKey(),
                r.getPayload(),
                OutboxStatus.valueOf(r.getStatus()),
                toInstant(r.getCreatedAt()),
                r.getPublishedAt() != null ? toInstant(r.getPublishedAt()) : null,
                r.getRetryCount(),
                r.getLastError(),
                r.getRowVersion()
            ));
    }

    public List<OutboxEvent> fetchFailed() {
        return dsl
            .selectFrom(OUTBOX_EVENTS)
            .where(OUTBOX_EVENTS.STATUS.eq(OutboxStatus.FAILED.name()))
            .fetch()
            .map(r -> new OutboxEvent(
                r.getId(), r.getAggregateType(), r.getAggregateId(),
                r.getEventType(), r.getTopic(), r.getKafkaKey(), r.getPayload(),
                OutboxStatus.FAILED, toInstant(r.getCreatedAt()),
                null, r.getRetryCount(), r.getLastError(), r.getRowVersion()
            ));
    }

    // ------------------------------------------------------------------
    // State transitions (optimistic-lock via row_version)
    // ------------------------------------------------------------------

    public void markPublished(UUID id, long currentRowVersion) {
        int updated = dsl.update(OUTBOX_EVENTS)
            .set(OUTBOX_EVENTS.STATUS,        OutboxStatus.PUBLISHED.name())
            .set(OUTBOX_EVENTS.PUBLISHED_AT,  OffsetDateTime.now(ZoneOffset.UTC))
            .set(OUTBOX_EVENTS.ROW_VERSION,   currentRowVersion + 1)
            .where(OUTBOX_EVENTS.ID.eq(id))
            .and(OUTBOX_EVENTS.ROW_VERSION.eq(currentRowVersion))
            .execute();
        if (updated == 0) {
            throw new IllegalStateException("Optimistic lock failure marking outbox event published: " + id);
        }
    }

    public void markFailed(UUID id, long currentRowVersion, String error) {
        dsl.update(OUTBOX_EVENTS)
            .set(OUTBOX_EVENTS.STATUS,      OutboxStatus.FAILED.name())
            .set(OUTBOX_EVENTS.LAST_ERROR,  error)
            .set(OUTBOX_EVENTS.RETRY_COUNT, OUTBOX_EVENTS.RETRY_COUNT.plus(1))
            .set(OUTBOX_EVENTS.ROW_VERSION, currentRowVersion + 1)
            .where(OUTBOX_EVENTS.ID.eq(id))
            .execute();
    }

    public void resetToPending(UUID id) {
        dsl.update(OUTBOX_EVENTS)
            .set(OUTBOX_EVENTS.STATUS, OutboxStatus.PENDING.name())
            .where(OUTBOX_EVENTS.ID.eq(id))
            .execute();
    }

    public int deletePublishedBefore(Instant cutoff) {
        return dsl.deleteFrom(OUTBOX_EVENTS)
            .where(OUTBOX_EVENTS.STATUS.eq(OutboxStatus.PUBLISHED.name()))
            .and(OUTBOX_EVENTS.PUBLISHED_AT.lessThan(OffsetDateTime.ofInstant(cutoff, ZoneOffset.UTC)))
            .execute();
    }

    // ------------------------------------------------------------------

    private static OffsetDateTime toOffset(Instant instant) {
        return instant == null ? null : OffsetDateTime.ofInstant(instant, ZoneOffset.UTC);
    }

    private static Instant toInstant(OffsetDateTime odt) {
        return odt == null ? null : odt.toInstant();
    }
}
