package com.oms.command.order.infrastructure;

import com.oms.command.order.domain.OrderStatus;
import com.oms.command.order.domain.OrderVersion;
import com.oms.common.avro.Side;
import lombok.RequiredArgsConstructor;
import org.jooq.DSLContext;
import org.springframework.stereotype.Repository;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Optional;
import java.util.UUID;

import static com.oms.command.generated.Tables.ORDER_VERSIONS;

/** jOOQ repository for the command-side Order write model. INSERT-only. */
@Repository
@RequiredArgsConstructor
public class OrderRepository {

    private final DSLContext dsl;

    public long insert(OrderVersion order) {
        return dsl.insertInto(ORDER_VERSIONS)
            .set(ORDER_VERSIONS.ORDER_ID,        order.orderId())
            .set(ORDER_VERSIONS.IDEMPOTENCY_KEY, order.idempotencyKey())
            .set(ORDER_VERSIONS.VERSION,         order.version())
            .set(ORDER_VERSIONS.RFQ_ID,          order.rfqId())
            .set(ORDER_VERSIONS.QUOTE_ID,        order.quoteId())
            .set(ORDER_VERSIONS.USER_ID,         order.userId())
            .set(ORDER_VERSIONS.DESK_ID,         order.deskId())
            .set(ORDER_VERSIONS.INSTRUMENT_ID,   order.instrumentId())
            .set(ORDER_VERSIONS.CURRENCY_PAIR,   order.currencyPair())
            .set(ORDER_VERSIONS.NOTIONAL,        order.notional())
            .set(ORDER_VERSIONS.CURRENCY,        order.currency())
            .set(ORDER_VERSIONS.SIDE,            order.side().name())
            .set(ORDER_VERSIONS.CLIENT_PRICE,    order.clientPrice())
            .set(ORDER_VERSIONS.STATUS,          order.status().name())
            .set(ORDER_VERSIONS.CREATED_AT,      OffsetDateTime.ofInstant(order.createdAt(), ZoneOffset.UTC))
            .set(ORDER_VERSIONS.ROW_VERSION,     0L)
            .returningResult(ORDER_VERSIONS.ID)
            .fetchOne()
            .value1();
    }

    public Optional<OrderVersion> findByIdempotencyKey(String key) {
        return dsl.selectFrom(ORDER_VERSIONS)
            .where(ORDER_VERSIONS.IDEMPOTENCY_KEY.eq(key))
            .orderBy(ORDER_VERSIONS.VERSION.desc())
            .limit(1)
            .fetchOptional()
            .map(r -> new OrderVersion(
                r.getId(), r.getOrderId(), r.getIdempotencyKey(), r.getVersion(),
                r.getRfqId(), r.getQuoteId(),
                r.getUserId(), r.getDeskId(), r.getInstrumentId(),
                r.getCurrencyPair(), r.getNotional(), r.getCurrency(),
                Side.valueOf(r.getSide()), r.getClientPrice(),
                OrderStatus.valueOf(r.getStatus()),
                r.getCreatedAt().toInstant()
            ));
    }

    public Optional<OrderVersion> findLatestByOrderId(UUID orderId) {
        return dsl.selectFrom(ORDER_VERSIONS)
            .where(ORDER_VERSIONS.ORDER_ID.eq(orderId))
            .orderBy(ORDER_VERSIONS.VERSION.desc())
            .limit(1)
            .fetchOptional()
            .map(r -> new OrderVersion(
                r.getId(), r.getOrderId(), r.getIdempotencyKey(), r.getVersion(),
                r.getRfqId(), r.getQuoteId(),
                r.getUserId(), r.getDeskId(), r.getInstrumentId(),
                r.getCurrencyPair(), r.getNotional(), r.getCurrency(),
                Side.valueOf(r.getSide()), r.getClientPrice(),
                OrderStatus.valueOf(r.getStatus()),
                r.getCreatedAt().toInstant()
            ));
    }
}
