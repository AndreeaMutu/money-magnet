package com.oms.command.order.api;

import com.oms.command.rfq.api.RfqDtos;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

public final class OrderDtos {
    private OrderDtos() {}

    public record CreateOrderRequest(
        @NotBlank String idempotencyKey,
        @NotBlank String userId,
        @NotNull  UUID rfqId,
        @NotNull  UUID quoteId,
        @NotNull  RfqDtos.Side side
    ) {}

    public record CreateOrderResponse(
        UUID orderId, String idempotencyKey, int version,
        UUID rfqId, UUID quoteId,
        String userId, String deskId,
        String currencyPair, BigDecimal notional, String currency,
        RfqDtos.Side side, BigDecimal clientPrice,
        String status, Instant createdAt
    ) {}
}
