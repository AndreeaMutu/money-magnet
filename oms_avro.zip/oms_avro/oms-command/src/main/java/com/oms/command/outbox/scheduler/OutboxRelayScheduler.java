package com.oms.command.outbox.scheduler;

import com.oms.command.outbox.domain.OutboxEvent;
import com.oms.command.outbox.infrastructure.OutboxRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * Outbox relay — polls PENDING rows and forwards Avro bytes to Kafka.
 *
 * <p>Uses a byte-passthrough {@link KafkaTemplate} (ByteArraySerializer)
 * so the bytes stored in outbox_events.payload (Confluent wire format written
 * at INSERT time by KafkaAvroSerializer) are forwarded verbatim — no
 * re-serialisation, no schema ID mismatch possible.
 *
 * <p>Failure handling:
 * <ul>
 *   <li>Kafka failure → {@code markFailed}; {@code retryFailed} reschedules.</li>
 *   <li>Optimistic lock race → logged and skipped; row stays PENDING.</li>
 *   <li>App crash after send but before {@code markPublished} → row stays
 *       PENDING, re-sent on restart; consumers skip duplicates via DB uq constraint.</li>
 * </ul>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class OutboxRelayScheduler {

    private static final int BATCH_SIZE  = 100;
    private static final int MAX_RETRIES = 5;

    private final OutboxRepository               outboxRepository;
    private final KafkaTemplate<String, byte[]>  byteKafkaTemplate;

    @Scheduled(fixedDelayString = "${oms.outbox.relay.interval-ms:200}")
    @Transactional
    public void relay() {
        List<OutboxEvent> batch = outboxRepository.fetchPendingSkipLocked(BATCH_SIZE);
        if (batch.isEmpty()) return;

        log.debug("Outbox relay: processing {} events", batch.size());

        for (OutboxEvent event : batch) {
            try {
                var kafkaRecord = new ProducerRecord<String, byte[]>(
                    event.topic(), event.kafkaKey(), event.payload());
                byteKafkaTemplate.send(kafkaRecord).get();  // sync for delivery guarantee
                outboxRepository.markPublished(event.id(), event.rowVersion());
                log.debug("Outbox published id={} topic={}", event.id(), event.topic());
            } catch (IllegalStateException e) {
                // Optimistic lock missed — another instance already published this row
                log.warn("Outbox optimistic lock miss id={} — will retry on next poll", event.id());
            } catch (Exception e) {
                outboxRepository.markFailed(event.id(), event.rowVersion(),
                    truncate(e.getMessage(), 500));
                log.error("Outbox publish failed id={} error={}", event.id(), e.getMessage());
            }
        }
    }

    @Scheduled(fixedDelayString = "${oms.outbox.retry.interval-ms:5000}")
    @Transactional
    public void retryFailed() {
        outboxRepository.fetchFailed().forEach(event -> {
            if (event.retryCount() < MAX_RETRIES) {
                outboxRepository.resetToPending(event.id());
                log.info("Outbox retry scheduled id={} retryCount={}", event.id(), event.retryCount());
            } else {
                log.error("Outbox event exceeded max retries, leaving FAILED: id={}", event.id());
            }
        });
    }

    @Scheduled(cron = "${oms.outbox.cleanup.cron:0 0 2 * * *}")
    @Transactional
    public void cleanupPublished() {
        Instant cutoff = Instant.now().minus(24, ChronoUnit.HOURS);
        int deleted = outboxRepository.deletePublishedBefore(cutoff);
        log.info("Outbox cleanup: deleted {} published events older than {}", deleted, cutoff);
    }

    private static String truncate(String s, int max) {
        return (s == null) ? "" : (s.length() <= max ? s : s.substring(0, max));
    }
}
