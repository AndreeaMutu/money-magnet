package com.oms.command;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class OmsCommandApplication {
    public static void main(String[] args) {
        SpringApplication.run(OmsCommandApplication.class, args);
    }
}
