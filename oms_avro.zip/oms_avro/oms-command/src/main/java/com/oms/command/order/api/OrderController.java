package com.oms.command.order.api;

import com.oms.command.order.application.OrderCommandService;
import com.oms.command.order.application.RfqExpiredException;
import com.oms.command.order.api.OrderDtos.CreateOrderRequest;
import com.oms.command.order.api.OrderDtos.CreateOrderResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.NoSuchElementException;

@Slf4j
@RestController
@RequestMapping("/api/v1/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderCommandService orderCommandService;

    /**
     * POST /api/v1/orders
     *
     * Creates an order against a valid, non-expired RFQ.
     * Returns 409 CONFLICT if RFQ has expired.
     * Idempotent on idempotency-key.
     */
    @PostMapping
    public ResponseEntity<CreateOrderResponse> createOrder(
        @Valid @RequestBody CreateOrderRequest request
    ) {
        log.debug("POST /orders idempotencyKey={} userId={}", request.idempotencyKey(), request.userId());
        CreateOrderResponse response = orderCommandService.createOrder(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @ExceptionHandler(RfqExpiredException.class)
    ResponseEntity<ProblemDetail> handleRfqExpired(RfqExpiredException ex) {
        var problem = ProblemDetail.forStatusAndDetail(HttpStatus.CONFLICT, ex.getMessage());
        problem.setTitle("RFQ Expired");
        return ResponseEntity.status(HttpStatus.CONFLICT).body(problem);
    }

    @ExceptionHandler(NoSuchElementException.class)
    ResponseEntity<ProblemDetail> handleNotFound(NoSuchElementException ex) {
        var problem = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
        problem.setTitle("Resource Not Found");
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(problem);
    }
}
