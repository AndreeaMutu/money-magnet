package com.oms.command.order.application;

import com.oms.command.config.AvroOutboxHelper;
import com.oms.command.order.api.OrderDtos.CreateOrderRequest;
import com.oms.command.order.api.OrderDtos.CreateOrderResponse;
import com.oms.command.order.domain.OrderVersion;
import com.oms.command.order.infrastructure.OrderRepository;
import com.oms.command.outbox.domain.OutboxEvent;
import com.oms.command.outbox.infrastructure.OutboxRepository;
import com.oms.command.rfq.domain.RfqVersion;
import com.oms.command.rfq.infrastructure.RfqRepository;
import com.oms.common.avro.OrderCreated;
import com.oms.common.avro.Side;
import com.oms.common.config.KafkaTopics;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.NoSuchElementException;

/**
 * Order command service.
 *
 * <p>Pre-trade validation sequence (all inside one @Transactional):
 * <ol>
 *   <li>Idempotency — return existing if key seen.</li>
 *   <li>RFQ existence + expiry check.</li>
 *   <li>Quote client-price lookup from query schema (cross-schema jOOQ read).</li>
 *   <li>Domain entity INSERT.</li>
 *   <li>Avro serialisation → outbox INSERT (BYTEA).</li>
 * </ol>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class OrderCommandService {

    private final OrderRepository       orderRepository;
    private final RfqRepository         rfqRepository;
    private final OutboxRepository      outboxRepository;
    private final QuoteReadModelLookup  quoteReadModelLookup;
    private final AvroOutboxHelper      avroOutboxHelper;

    @Transactional
    public CreateOrderResponse createOrder(CreateOrderRequest request) {

        // 1. Idempotency
        var existing = orderRepository.findByIdempotencyKey(request.idempotencyKey());
        if (existing.isPresent()) {
            log.info("Idempotent order key={} orderId={}", request.idempotencyKey(), existing.get().orderId());
            return toResponse(existing.get());
        }

        // 2. RFQ validation
        RfqVersion rfq = rfqRepository.findLatestByRfqId(request.rfqId())
            .orElseThrow(() -> new NoSuchElementException("RFQ not found: " + request.rfqId()));
        if (rfq.isExpired()) throw new RfqExpiredException(request.rfqId());

        // 3. Quote lookup (cross-schema read)
        var quote = quoteReadModelLookup.findActiveQuote(request.rfqId(), request.quoteId());

        // 4. Create domain value object
        OrderVersion order = OrderVersion.createInitial(
            request.idempotencyKey(),
            request.rfqId(), request.quoteId(),
            request.userId(), rfq.deskId(), rfq.instrumentId(),
            rfq.currencyPair(), rfq.notional(), rfq.currency(),
            Side.valueOf(request.side().name()),
            quote.clientAskPrice()
        );
        orderRepository.insert(order);

        // 5. Build + pre-serialise Avro event → outbox BYTEA
        OrderCreated avroEvent = OrderCreated.newBuilder()
            .setOrderId(order.orderId().toString())
            .setRfqId(order.rfqId().toString())
            .setQuoteId(order.quoteId().toString())
            .setCorrelationId(order.idempotencyKey())
            .setOccurredAt(Instant.ofEpochSecond(order.createdAt().toEpochMilli() * 1000L))
            .setVersion(order.version())
            .setUserId(order.userId())
            .setDeskId(order.deskId())
            .setInstrumentId(order.instrumentId())
            .setCurrencyPair(order.currencyPair())
            .setNotional(order.notional())
            .setCurrency(order.currency())
            .setSide(order.side())
            .setClientPrice(order.clientPrice())
            .build();

        byte[] payload = avroOutboxHelper.toBytes(KafkaTopics.ORDER_EVENTS_V1, avroEvent);
        outboxRepository.insertPending(OutboxEvent.pending(
            "ORDER", order.orderId().toString(), "ORDER_CREATED",
            KafkaTopics.ORDER_EVENTS_V1, order.orderId().toString(), payload
        ));

        log.info("Order created orderId={} rfqId={} userId={}", order.orderId(), rfq.rfqId(), order.userId());
        return toResponse(order);
    }

    private CreateOrderResponse toResponse(OrderVersion o) {
        return new CreateOrderResponse(
            o.orderId(), o.idempotencyKey(), o.version(),
            o.rfqId(), o.quoteId(), o.userId(), o.deskId(),
            o.currencyPair(), o.notional(), o.currency(),
            com.oms.command.rfq.api.RfqDtos.Side.valueOf(o.side().name()),
            o.clientPrice(), o.status().name(), o.createdAt()
        );
    }
}
