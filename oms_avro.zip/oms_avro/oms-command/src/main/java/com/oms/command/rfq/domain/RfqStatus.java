package com.oms.command.rfq.domain;

public enum RfqStatus {
    CREATED, QUOTED, EXPIRED, TRADED, CANCELLED
}
