package com.oms.command.rfq.infrastructure;

import com.oms.command.rfq.domain.RfqStatus;
import com.oms.command.rfq.domain.RfqVersion;
import com.oms.common.avro.Side;
import lombok.RequiredArgsConstructor;
import org.jooq.DSLContext;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Optional;
import java.util.UUID;

import static com.oms.command.generated.Tables.RFQ_VERSIONS;

/**
 * jOOQ repository for the command-side RFQ write model.
 * All operations are INSERT-only — no UPDATE, no DELETE.
 */
@Repository
@RequiredArgsConstructor
public class RfqRepository {

    private final DSLContext dsl;

    /**
     * Insert a new version row.  Returns the database-assigned surrogate id.
     */
    public long insert(RfqVersion rfq) {
        return dsl.insertInto(RFQ_VERSIONS)
            .set(RFQ_VERSIONS.RFQ_ID,          rfq.rfqId())
            .set(RFQ_VERSIONS.IDEMPOTENCY_KEY, rfq.idempotencyKey())
            .set(RFQ_VERSIONS.VERSION,         rfq.version())
            .set(RFQ_VERSIONS.USER_ID,         rfq.userId())
            .set(RFQ_VERSIONS.DESK_ID,         rfq.deskId())
            .set(RFQ_VERSIONS.INSTRUMENT_ID,   rfq.instrumentId())
            .set(RFQ_VERSIONS.CURRENCY_PAIR,   rfq.currencyPair())
            .set(RFQ_VERSIONS.NOTIONAL,        rfq.notional())
            .set(RFQ_VERSIONS.CURRENCY,        rfq.currency())
            .set(RFQ_VERSIONS.SIDE,            rfq.side().name())
            .set(RFQ_VERSIONS.STATUS,          rfq.status().name())
            .set(RFQ_VERSIONS.EXPIRES_AT,      toOffset(rfq.expiresAt()))
            .set(RFQ_VERSIONS.CREATED_AT,      toOffset(rfq.createdAt()))
            .set(RFQ_VERSIONS.ROW_VERSION,     0L)
            .returningResult(RFQ_VERSIONS.ID)
            .fetchOne()
            .value1();
    }

    /** Idempotency check — returns the latest version for a key if it exists. */
    public Optional<RfqVersion> findByIdempotencyKey(String key) {
        return dsl.selectFrom(RFQ_VERSIONS)
            .where(RFQ_VERSIONS.IDEMPOTENCY_KEY.eq(key))
            .orderBy(RFQ_VERSIONS.VERSION.desc())
            .limit(1)
            .fetchOptional()
            .map(this::toRfqVersion);
    }

    /** Fetch latest version of an RFQ by its business id. */
    public Optional<RfqVersion> findLatestByRfqId(UUID rfqId) {
        return dsl.selectFrom(RFQ_VERSIONS)
            .where(RFQ_VERSIONS.RFQ_ID.eq(rfqId))
            .orderBy(RFQ_VERSIONS.VERSION.desc())
            .limit(1)
            .fetchOptional()
            .map(this::toRfqVersion);
    }

    // ------------------------------------------------------------------

    private RfqVersion toRfqVersion(org.jooq.Record r) {
        return new RfqVersion(
            r.get(RFQ_VERSIONS.ID),
            r.get(RFQ_VERSIONS.RFQ_ID),
            r.get(RFQ_VERSIONS.IDEMPOTENCY_KEY),
            r.get(RFQ_VERSIONS.VERSION),
            r.get(RFQ_VERSIONS.USER_ID),
            r.get(RFQ_VERSIONS.DESK_ID),
            r.get(RFQ_VERSIONS.INSTRUMENT_ID),
            r.get(RFQ_VERSIONS.CURRENCY_PAIR),
            r.get(RFQ_VERSIONS.NOTIONAL),
            r.get(RFQ_VERSIONS.CURRENCY),
            Side.valueOf(r.get(RFQ_VERSIONS.SIDE)),
            RfqStatus.valueOf(r.get(RFQ_VERSIONS.STATUS)),
            r.get(RFQ_VERSIONS.EXPIRES_AT).toInstant(),
            r.get(RFQ_VERSIONS.CREATED_AT).toInstant()
        );
    }

    private static OffsetDateTime toOffset(java.time.Instant i) {
        return OffsetDateTime.ofInstant(i, ZoneOffset.UTC);
    }
}
