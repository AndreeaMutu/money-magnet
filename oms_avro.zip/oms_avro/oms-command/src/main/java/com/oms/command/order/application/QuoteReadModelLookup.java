package com.oms.command.order.application;

import lombok.RequiredArgsConstructor;
import org.jooq.DSLContext;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.NoSuchElementException;
import java.util.UUID;

//import static com.oms.query.generated.Tables.QUOTE_READ_MODEL;

/**
 * Cross-schema read: fetches the enriched client price from the query schema
 * so the command side can embed it in the order at creation time.
 *
 * Uses the query module's jOOQ-generated table reference. Both schemas live in
 * the same Postgres instance, so a single DSLContext suffices. The query schema
 * must be on the search_path or the generated table reference must be fully qualified —
 * jOOQ codegen includes the schema in the table reference by default.
 */
@Component
@RequiredArgsConstructor
public class QuoteReadModelLookup {

    private final DSLContext dsl;

    public record QuoteSnapshot(
        UUID       quoteId,
        UUID       rfqId,
        BigDecimal clientAskPrice,
        Instant    expiresAt,
        String     status
    ) {}

    public QuoteSnapshot findActiveQuote(UUID rfqId, UUID quoteId) {
//        return dsl.selectFrom(QUOTE_READ_MODEL)
//            .where(QUOTE_READ_MODEL.RFQ_ID.eq(rfqId))
//            .and(QUOTE_READ_MODEL.QUOTE_ID.eq(quoteId))
//            .orderBy(QUOTE_READ_MODEL.VERSION.desc())
//            .limit(1)
//            .fetchOptional()
//            .map(r -> new QuoteSnapshot(
//                r.getQuoteId(), r.getRfqId(),
//                r.getClientAskPrice(),
//                r.getExpiresAt().toInstant(),
//                r.getStatus()
//            ))
//            .orElseThrow(() -> new NoSuchElementException(
//                "No active quote for rfqId=" + rfqId + " quoteId=" + quoteId));
        return null;
    }
}
