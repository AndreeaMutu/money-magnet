package com.oms.command.rfq.api;

import com.oms.command.rfq.application.RfqCommandService;
import com.oms.command.rfq.api.RfqDtos.CreateRfqRequest;
import com.oms.command.rfq.api.RfqDtos.CreateRfqResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/v1/rfqs")
@RequiredArgsConstructor
public class RfqController {

    private final RfqCommandService rfqCommandService;

    /**
     * POST /api/v1/rfqs
     *
     * Accepts a new RFQ. Idempotent: replaying the same idempotency-key
     * returns the original 200 response without side effects.
     */
    @PostMapping
    public ResponseEntity<CreateRfqResponse> createRfq(
        @Valid @RequestBody CreateRfqRequest request
    ) {
        log.debug("POST /rfqs idempotencyKey={} userId={}", request.idempotencyKey(), request.userId());
        CreateRfqResponse response = rfqCommandService.createRfq(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }
}
