package com.oms.command.rfq.api;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

public final class RfqDtos {
    private RfqDtos() {}

    /** Side enum mirrored locally so the REST layer has no Avro dependency. */
    public enum Side { BUY, SELL }

    public record CreateRfqRequest(
        @NotBlank String idempotencyKey,
        @NotBlank String userId,
        @NotBlank String deskId,
        @NotBlank String instrumentId,
        @NotBlank String currencyPair,
        @NotNull @Positive BigDecimal notional,
        @NotBlank String currency,
        @NotNull  Side side,
        Integer ttlSeconds
    ) {}

    public record CreateRfqResponse(
        UUID rfqId, String idempotencyKey, int version,
        String status, Instant expiresAt, Instant createdAt
    ) {}
}
