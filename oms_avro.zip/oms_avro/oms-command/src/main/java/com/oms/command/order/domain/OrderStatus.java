package com.oms.command.order.domain;

public enum OrderStatus {
    PENDING, SUBMITTED, FILLED, PARTIALLY_FILLED, REJECTED, CANCELLED
}
