package com.oms.command.config;

import io.confluent.kafka.serializers.KafkaAvroSerializer;
import io.confluent.kafka.serializers.KafkaAvroSerializerConfig;
import org.apache.avro.specific.SpecificRecord;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.ByteArraySerializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.jooq.DSLContext;
import org.jooq.SQLDialect;
import org.jooq.impl.DataSourceConnectionProvider;
import org.jooq.impl.DefaultConfiguration;
import org.jooq.impl.DefaultDSLContext;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.TransactionAwareDataSourceProxy;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

/**
 * Infrastructure beans for the command module.
 *
 * Two Kafka templates are registered:
 *   - avroKafkaTemplate:  used by application services; KafkaAvroSerializer encodes
 *     SpecificRecord + registers schema; pre-serialised bytes are stored in outbox BYTEA.
 *   - byteKafkaTemplate:  used by OutboxRelayScheduler; ByteArraySerializer forwards
 *     the stored bytes verbatim — no re-serialisation, no schema mismatch possible.
 *
 * DSLContext participates in Spring @Transactional via TransactionAwareDataSourceProxy,
 * giving atomic (domain INSERT + outbox INSERT) semantics.
 */
@Configuration
public class CommandInfraConfig {

    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;

    @Value("${oms.kafka.schema-registry-url}")
    private String schemaRegistryUrl;

    @Bean @Primary
    public DSLContext dslContext(DataSource dataSource) {
        var proxy = new TransactionAwareDataSourceProxy(dataSource);
        var cp    = new DataSourceConnectionProvider(proxy);
        return new DefaultDSLContext(new DefaultConfiguration().set(cp).set(SQLDialect.POSTGRES));
    }

    @Bean("avroProducerFactory")
    public ProducerFactory<String, SpecificRecord> avroProducerFactory() {
        Map<String, Object> p = new HashMap<>();
        p.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,              bootstrapServers);
        p.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,           StringSerializer.class);
        p.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,         KafkaAvroSerializer.class);
        p.put(KafkaAvroSerializerConfig.SCHEMA_REGISTRY_URL_CONFIG, schemaRegistryUrl);
        p.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG,             true);
        p.put(ProducerConfig.ACKS_CONFIG,                           "all");
        p.put(ProducerConfig.RETRIES_CONFIG,                        Integer.MAX_VALUE);
        p.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, 5);
        return new DefaultKafkaProducerFactory<>(p);
    }

    @Bean("avroKafkaTemplate")
    public KafkaTemplate<String, SpecificRecord> avroKafkaTemplate(
            @Qualifier("avroProducerFactory") ProducerFactory<String, SpecificRecord> pf) {
        return new KafkaTemplate<>(pf);
    }

    @Bean("byteProducerFactory")
    public ProducerFactory<String, byte[]> byteProducerFactory() {
        Map<String, Object> p = new HashMap<>();
        p.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,              bootstrapServers);
        p.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,           StringSerializer.class);
        p.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,         ByteArraySerializer.class);
        p.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG,             true);
        p.put(ProducerConfig.ACKS_CONFIG,                           "all");
        p.put(ProducerConfig.RETRIES_CONFIG,                        Integer.MAX_VALUE);
        p.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, 5);
        return new DefaultKafkaProducerFactory<>(p);
    }

    @Bean("byteKafkaTemplate")
    public KafkaTemplate<String, byte[]> byteKafkaTemplate(
            @Qualifier("byteProducerFactory") ProducerFactory<String, byte[]> pf) {
        return new KafkaTemplate<>(pf);
    }
}
