package com.oms.command.outbox.domain;

public enum OutboxStatus {
    PENDING, PUBLISHED, FAILED
}
