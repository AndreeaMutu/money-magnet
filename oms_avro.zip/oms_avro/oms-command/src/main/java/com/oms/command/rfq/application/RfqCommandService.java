package com.oms.command.rfq.application;

import com.oms.command.config.AvroOutboxHelper;
import com.oms.command.outbox.domain.OutboxEvent;
import com.oms.command.outbox.infrastructure.OutboxRepository;
import com.oms.command.rfq.api.RfqDtos.CreateRfqRequest;
import com.oms.command.rfq.api.RfqDtos.CreateRfqResponse;
import com.oms.command.rfq.domain.RfqVersion;
import com.oms.command.rfq.infrastructure.RfqRepository;
import com.oms.common.avro.RfqCreated;
import com.oms.common.avro.Side;
import com.oms.common.config.KafkaTopics;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

/**
 * RFQ command service.
 *
 * <p>Transaction boundary contains:
 * <ol>
 *   <li>Idempotency check (SELECT)</li>
 *   <li>Domain entity INSERT (command.rfq_versions)</li>
 *   <li>Avro serialisation of {@link RfqCreated} — byte[] produced by
 *       {@link AvroOutboxHelper} using the Confluent KafkaAvroSerializer,
 *       which registers the schema in the Schema Registry and prepends the
 *       5-byte magic header.</li>
 *   <li>Outbox INSERT (command.outbox_events, BYTEA payload) in the SAME tx.</li>
 * </ol>
 *
 * <p>If the transaction rolls back for any reason, neither the RFQ row nor the
 * outbox row is committed — no orphaned events, no phantom entities.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RfqCommandService {

    private static final int DEFAULT_TTL_SECONDS = 30;

    private final RfqRepository    rfqRepository;
    private final OutboxRepository outboxRepository;
    private final AvroOutboxHelper avroOutboxHelper;

    @Transactional
    public CreateRfqResponse createRfq(CreateRfqRequest request) {

        // 1. Idempotency
        var existing = rfqRepository.findByIdempotencyKey(request.idempotencyKey());
        if (existing.isPresent()) {
            log.info("Idempotent RFQ key={} rfqId={}", request.idempotencyKey(), existing.get().rfqId());
            return toResponse(existing.get());
        }

        // 2. Create domain value object
        int ttl = request.ttlSeconds() != null ? request.ttlSeconds() : DEFAULT_TTL_SECONDS;
        RfqVersion rfq = RfqVersion.createInitial(
            request.idempotencyKey(),
            request.userId(), request.deskId(), request.instrumentId(),
            request.currencyPair(), request.notional(), request.currency(),
            Side.valueOf(request.side().name()),
            Instant.now().plus(ttl, ChronoUnit.SECONDS)
        );

        // 3. Persist entity
        rfqRepository.insert(rfq);

        // 4. Build Avro event
        RfqCreated avroEvent = RfqCreated.newBuilder()
            .setRfqId(rfq.rfqId().toString())
            .setCorrelationId(rfq.idempotencyKey())
            .setOccurredAt(Instant.ofEpochSecond(rfq.createdAt().toEpochMilli() * 1000L))  // micros
            .setVersion(rfq.version())
            .setUserId(rfq.userId())
            .setDeskId(rfq.deskId())
            .setInstrumentId(rfq.instrumentId())
            .setCurrencyPair(rfq.currencyPair())
            .setNotional(rfq.notional())
            .setCurrency(rfq.currency())
            .setSide(rfq.side())
            .setExpiresAt(Instant.ofEpochSecond(rfq.expiresAt().toEpochMilli() * 1000L))
            .build();

        // 5. Pre-serialise → BYTEA in outbox (same tx)
        byte[] payload = avroOutboxHelper.toBytes(KafkaTopics.RFQ_EVENTS_V1, avroEvent);
        outboxRepository.insertPending(OutboxEvent.pending(
            "RFQ", rfq.rfqId().toString(), "RFQ_CREATED",
            KafkaTopics.RFQ_EVENTS_V1, rfq.rfqId().toString(), payload
        ));

        log.info("RFQ created rfqId={} userId={}", rfq.rfqId(), rfq.userId());
        return toResponse(rfq);
    }

    private CreateRfqResponse toResponse(RfqVersion rfq) {
        return new CreateRfqResponse(
            rfq.rfqId(), rfq.idempotencyKey(), rfq.version(),
            rfq.status().name(), rfq.expiresAt(), rfq.createdAt()
        );
    }
}
