package com.oms.command.order.domain;

import com.oms.common.avro.Side;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

/** Order write-model value object. Immutable; transitions produce new instances. */
public record OrderVersion(
    Long       id,
    UUID       orderId,
    String     idempotencyKey,
    int        version,
    UUID       rfqId,
    UUID       quoteId,
    String     userId,
    String     deskId,
    String     instrumentId,
    String     currencyPair,
    BigDecimal notional,
    String     currency,
    Side       side,
    BigDecimal clientPrice,
    OrderStatus status,
    Instant    createdAt
) {
    public static OrderVersion createInitial(
        String idempotencyKey,
        UUID rfqId, UUID quoteId,
        String userId, String deskId, String instrumentId,
        String currencyPair, BigDecimal notional, String currency,
        Side side, BigDecimal clientPrice
    ) {
        return new OrderVersion(
            null, UUID.randomUUID(), idempotencyKey, 1,
            rfqId, quoteId, userId, deskId, instrumentId,
            currencyPair, notional, currency, side, clientPrice,
            OrderStatus.PENDING, Instant.now()
        );
    }

    public OrderVersion nextVersion(OrderStatus newStatus) {
        return new OrderVersion(
            null, orderId, idempotencyKey, version + 1,
            rfqId, quoteId, userId, deskId, instrumentId,
            currencyPair, notional, currency, side, clientPrice,
            newStatus, Instant.now()
        );
    }
}
