package com.oms.command.order;

import com.oms.command.config.AvroOutboxHelper;
import com.oms.command.order.application.OrderCommandService;
import com.oms.command.order.application.QuoteReadModelLookup;
import com.oms.command.order.application.RfqExpiredException;
import com.oms.command.order.api.OrderDtos.CreateOrderRequest;
import com.oms.command.order.domain.OrderVersion;
import com.oms.command.order.infrastructure.OrderRepository;
import com.oms.command.outbox.infrastructure.OutboxRepository;
import com.oms.command.rfq.domain.RfqVersion;
import com.oms.command.rfq.infrastructure.RfqRepository;
import com.oms.common.avro.Side;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OrderCommandServiceTest {

    @Mock OrderRepository       orderRepository;
    @Mock RfqRepository         rfqRepository;
    @Mock OutboxRepository      outboxRepository;
    @Mock QuoteReadModelLookup  quoteReadModelLookup;
    @Mock AvroOutboxHelper      avroOutboxHelper;

    OrderCommandService service;
    UUID rfqId   = UUID.randomUUID();
    UUID quoteId = UUID.randomUUID();

    @BeforeEach
    void setUp() {
        service = new OrderCommandService(orderRepository, rfqRepository,
            outboxRepository, quoteReadModelLookup, avroOutboxHelper);
    }

    @Test
    void createOrder_rejectsExpiredRfq() {
        RfqVersion expired = RfqVersion.createInitial(
            "key-exp", "user-1", "desk-1", "EUR/USD-SPOT", "EUR/USD",
            BigDecimal.ONE, "USD", Side.BUY,
            Instant.now().minusSeconds(60)   // already expired
        );
        when(orderRepository.findByIdempotencyKey(anyString())).thenReturn(Optional.empty());
        when(rfqRepository.findLatestByRfqId(rfqId)).thenReturn(Optional.of(expired));

        assertThatThrownBy(() -> service.createOrder(validRequest()))
            .isInstanceOf(RfqExpiredException.class);

        verify(orderRepository, never()).insert(any());
        verify(outboxRepository, never()).insertPending(any());
    }

    @Test
    void createOrder_throwsWhenRfqNotFound() {
        when(orderRepository.findByIdempotencyKey(anyString())).thenReturn(Optional.empty());
        when(rfqRepository.findLatestByRfqId(rfqId)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.createOrder(validRequest()))
            .isInstanceOf(NoSuchElementException.class);
    }

    @Test
    void createOrder_idempotentOnDuplicateKey() {
        OrderVersion existingOrder = OrderVersion.createInitial(
            "idem-1", rfqId, quoteId, "user-1", "desk-1", "EUR/USD-SPOT",
            "EUR/USD", BigDecimal.valueOf(1_000_000), "USD",
            Side.BUY, new BigDecimal("1.08520")
        );
        when(orderRepository.findByIdempotencyKey("idem-1"))
            .thenReturn(Optional.of(existingOrder));

        service.createOrder(validRequest());

        verifyNoInteractions(rfqRepository, outboxRepository, avroOutboxHelper);
    }

    @Test
    void createOrder_happyPath_writesEntityAndOutbox() {
        RfqVersion validRfq = RfqVersion.createInitial(
            "key-rfq", "user-1", "desk-1", "EUR/USD-SPOT", "EUR/USD",
            BigDecimal.valueOf(1_000_000), "USD", Side.BUY,
            Instant.now().plusSeconds(30)
        );
        when(orderRepository.findByIdempotencyKey(anyString())).thenReturn(Optional.empty());
        when(rfqRepository.findLatestByRfqId(rfqId)).thenReturn(Optional.of(validRfq));
        when(quoteReadModelLookup.findActiveQuote(rfqId, quoteId)).thenReturn(
            new QuoteReadModelLookup.QuoteSnapshot(quoteId, rfqId,
                new BigDecimal("1.08520"), Instant.now().plusSeconds(30), "RECEIVED")
        );
        when(orderRepository.insert(any())).thenReturn(1L);
        when(avroOutboxHelper.toBytes(anyString(), any())).thenReturn(new byte[]{9, 8, 7});

        service.createOrder(validRequest());

        verify(orderRepository).insert(any(OrderVersion.class));
        verify(outboxRepository).insertPending(argThat(e ->
            e.eventType().equals("ORDER_CREATED") &&
            e.topic().equals("order.events.v1")
        ));
    }

    private CreateOrderRequest validRequest() {
        return new CreateOrderRequest("idem-1", "user-1", rfqId, quoteId,
            com.oms.command.rfq.api.RfqDtos.Side.BUY);
    }
}
