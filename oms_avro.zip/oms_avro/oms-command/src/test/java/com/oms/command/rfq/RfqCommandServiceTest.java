package com.oms.command.rfq;

import com.oms.command.config.AvroOutboxHelper;
import com.oms.command.outbox.domain.OutboxEvent;
import com.oms.command.outbox.infrastructure.OutboxRepository;
import com.oms.command.rfq.application.RfqCommandService;
import com.oms.command.rfq.api.RfqDtos.CreateRfqRequest;
import com.oms.command.rfq.api.RfqDtos.CreateRfqResponse;
import com.oms.command.rfq.api.RfqDtos.Side;
import com.oms.command.rfq.domain.RfqVersion;
import com.oms.command.rfq.infrastructure.RfqRepository;
import com.oms.common.avro.RfqCreated;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RfqCommandServiceTest {

    @Mock RfqRepository    rfqRepository;
    @Mock OutboxRepository outboxRepository;
    @Mock AvroOutboxHelper avroOutboxHelper;

    RfqCommandService service;

    @BeforeEach
    void setUp() {
        service = new RfqCommandService(rfqRepository, outboxRepository, avroOutboxHelper);
    }

    @Test
    void createRfq_persistsEntityAndOutboxEvent() {
        when(rfqRepository.findByIdempotencyKey("key-1")).thenReturn(Optional.empty());
        when(rfqRepository.insert(any())).thenReturn(1L);
        when(avroOutboxHelper.toBytes(anyString(), any())).thenReturn(new byte[]{1, 2, 3});

        CreateRfqResponse response = service.createRfq(validRequest("key-1"));

        assertThat(response.rfqId()).isNotNull();
        assertThat(response.version()).isEqualTo(1);
        assertThat(response.status()).isEqualTo("CREATED");

        verify(rfqRepository).insert(any(RfqVersion.class));

        ArgumentCaptor<OutboxEvent> captor = ArgumentCaptor.forClass(OutboxEvent.class);
        verify(outboxRepository).insertPending(captor.capture());

        OutboxEvent outbox = captor.getValue();
        assertThat(outbox.eventType()).isEqualTo("RFQ_CREATED");
        assertThat(outbox.topic()).isEqualTo("rfq.events.v1");
        assertThat(outbox.payload()).isEqualTo(new byte[]{1, 2, 3});
    }

    @Test
    void createRfq_idempotency_returnsExistingWithoutSideEffects() {
        RfqVersion existing = RfqVersion.createInitial(
            "key-1", "user-1", "desk-1", "EUR/USD-SPOT", "EUR/USD",
            BigDecimal.ONE, "USD", com.oms.common.avro.Side.BUY,
            Instant.now().plusSeconds(30)
        );
        when(rfqRepository.findByIdempotencyKey("key-1")).thenReturn(Optional.of(existing));

        service.createRfq(validRequest("key-1"));
        service.createRfq(validRequest("key-1")); // replay

        verify(rfqRepository, never()).insert(any());
        verifyNoInteractions(outboxRepository, avroOutboxHelper);
    }

    @Test
    void createRfq_avroPayload_isPreSerialisedBeforeOutboxInsert() {
        when(rfqRepository.findByIdempotencyKey(anyString())).thenReturn(Optional.empty());
        when(rfqRepository.insert(any())).thenReturn(1L);
        byte[] fakeBytes = "avro-wire-bytes".getBytes();
        when(avroOutboxHelper.toBytes(anyString(), any(RfqCreated.class))).thenReturn(fakeBytes);

        service.createRfq(validRequest("key-2"));

        // Verify toBytes was called with the correct topic
        verify(avroOutboxHelper).toBytes(eq("rfq.events.v1"), any(RfqCreated.class));

        // Verify the exact bytes from serialiser ended up in the outbox record
        ArgumentCaptor<OutboxEvent> captor = ArgumentCaptor.forClass(OutboxEvent.class);
        verify(outboxRepository).insertPending(captor.capture());
        assertThat(captor.getValue().payload()).isEqualTo(fakeBytes);
    }

    private CreateRfqRequest validRequest(String key) {
        return new CreateRfqRequest(key, "user-1", "desk-fx-1",
            "EUR/USD-SPOT", "EUR/USD",
            BigDecimal.valueOf(1_000_000), "USD", Side.BUY, 30);
    }
}
