package com.oms.command.outbox;

import com.oms.command.outbox.domain.OutboxEvent;
import com.oms.command.outbox.domain.OutboxStatus;
import com.oms.command.outbox.infrastructure.OutboxRepository;
import com.oms.command.outbox.scheduler.OutboxRelayScheduler;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;

import java.time.Instant;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OutboxRelaySchedulerTest {

    @Mock OutboxRepository              outboxRepository;
    @Mock KafkaTemplate<String, byte[]> byteKafkaTemplate;

    @Test
    void relay_marksPublishedOnSuccess() throws Exception {
        UUID id = UUID.randomUUID();
        OutboxEvent event = new OutboxEvent(
            id, "RFQ", id.toString(), "RFQ_CREATED",
            "rfq.events.v1", id.toString(),
            new byte[]{1, 2, 3},
            OutboxStatus.PENDING, Instant.now(),
            null, 0, null, 0L
        );
        when(outboxRepository.fetchPendingSkipLocked(anyInt())).thenReturn(List.of(event));

        @SuppressWarnings("unchecked")
        CompletableFuture<SendResult<String, byte[]>> future =
            CompletableFuture.completedFuture(mock(SendResult.class));
        when(byteKafkaTemplate.send(any(ProducerRecord.class))).thenReturn(future);

        new OutboxRelayScheduler(outboxRepository, byteKafkaTemplate).relay();

        // Verify raw bytes were sent verbatim
        @SuppressWarnings("unchecked")
        ArgumentCaptor<ProducerRecord<String, byte[]>> captor =
            ArgumentCaptor.forClass(ProducerRecord.class);
        verify(byteKafkaTemplate).send(captor.capture());
        assertThat(captor.getValue().value()).isEqualTo(new byte[]{1, 2, 3});
        assertThat(captor.getValue().topic()).isEqualTo("rfq.events.v1");

        verify(outboxRepository).markPublished(id, 0L);
    }

    @Test
    void relay_marksFailedOnKafkaError() {
        UUID id = UUID.randomUUID();
        OutboxEvent event = new OutboxEvent(
            id, "RFQ", id.toString(), "RFQ_CREATED",
            "rfq.events.v1", id.toString(), new byte[]{},
            OutboxStatus.PENDING, Instant.now(), null, 0, null, 0L
        );
        when(outboxRepository.fetchPendingSkipLocked(anyInt())).thenReturn(List.of(event));
        when(byteKafkaTemplate.send(any(ProducerRecord.class)))
            .thenThrow(new RuntimeException("broker down"));

        new OutboxRelayScheduler(outboxRepository, byteKafkaTemplate).relay();

        verify(outboxRepository).markFailed(eq(id), eq(0L), contains("broker down"));
        verify(outboxRepository, never()).markPublished(any(), anyLong());
    }

    @Test
    void relay_noOp_whenNoPendingEvents() {
        when(outboxRepository.fetchPendingSkipLocked(anyInt())).thenReturn(List.of());

        new OutboxRelayScheduler(outboxRepository, byteKafkaTemplate).relay();

        verifyNoInteractions(byteKafkaTemplate);
    }

    @Test
    void retryFailed_resetsPendingWhenUnderMaxRetries() {
        UUID id = UUID.randomUUID();
        OutboxEvent failed = new OutboxEvent(
            id, "ORDER", id.toString(), "ORDER_CREATED",
            "order.events.v1", id.toString(), new byte[]{},
            OutboxStatus.FAILED, Instant.now(), null, 2, "timeout", 1L
        );
        when(outboxRepository.fetchFailed()).thenReturn(List.of(failed));

        new OutboxRelayScheduler(outboxRepository, byteKafkaTemplate).retryFailed();

        verify(outboxRepository).resetToPending(id);
    }
}
