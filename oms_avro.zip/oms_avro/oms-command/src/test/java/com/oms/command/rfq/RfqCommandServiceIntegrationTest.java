package com.oms.command.rfq;

import com.oms.command.OmsCommandApplication;
import com.oms.command.outbox.domain.OutboxStatus;
import com.oms.command.outbox.infrastructure.OutboxRepository;
import com.oms.command.rfq.api.RfqDtos.CreateRfqRequest;
import com.oms.command.rfq.api.RfqDtos.Side;
import com.oms.command.rfq.application.RfqCommandService;
import com.oms.command.rfq.infrastructure.RfqRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.containers.KafkaContainer;
import org.testcontainers.containers.Network;

import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.postgresql.PostgreSQLContainer;
import org.testcontainers.utility.DockerImageName;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Full integration test: real Postgres (Liquibase-migrated) + real Kafka +
 * real Confluent Schema Registry, all via Testcontainers.
 *
 * Verifies the core transactional guarantee: RFQ entity row and outbox row
 * are committed together, and the outbox payload is valid Avro bytes
 * (starts with the Confluent 5-byte magic prefix 0x00).
 */
@SpringBootTest(classes = OmsCommandApplication.class)
@Testcontainers
class RfqCommandServiceIntegrationTest {

    static final Network network = Network.newNetwork();

    @Container
    static final PostgreSQLContainer postgres = new PostgreSQLContainer(DockerImageName.parse("postgres:16-alpine"))
        .withDatabaseName("oms").withUsername("oms").withPassword("oms");

    @Container
    static final KafkaContainer kafka = new KafkaContainer(
        DockerImageName.parse("confluentinc/cp-kafka:7.6.1")).withNetwork(network)
        .withNetworkAliases("kafka");

    @SuppressWarnings("resource")
    @Container
    static final GenericContainer<?> schemaRegistry = new GenericContainer<>(
        DockerImageName.parse("confluentinc/cp-schema-registry:7.6.1"))
        .withNetwork(network)
        .withEnv("SCHEMA_REGISTRY_HOST_NAME", "schema-registry")
        .withEnv("SCHEMA_REGISTRY_KAFKASTORE_BOOTSTRAP_SERVERS", "kafka:9092")
        .withEnv("SCHEMA_REGISTRY_LISTENERS", "http://0.0.0.0:8081")
        .withExposedPorts(8081)
        .dependsOn(kafka);

    @DynamicPropertySource
    static void overrideProps(DynamicPropertyRegistry reg) {
        reg.add("spring.datasource.url",               postgres::getJdbcUrl);
        reg.add("spring.datasource.username",           postgres::getUsername);
        reg.add("spring.datasource.password",           postgres::getPassword);
        reg.add("spring.kafka.bootstrap-servers",       kafka::getBootstrapServers);
        reg.add("oms.kafka.schema-registry-url", () ->
            "http://" + schemaRegistry.getHost() + ":" + schemaRegistry.getMappedPort(8081));
    }

    @Autowired RfqCommandService service;
    @Autowired RfqRepository     rfqRepository;
    @Autowired OutboxRepository  outboxRepository;

    @Test
    void createRfq_writesEntityAndAvroOutboxInOneTransaction() {
        var req = new CreateRfqRequest(
            "it-key-001", "user-alice", "desk-fx-1",
            "EUR/USD-SPOT", "EUR/USD",
            new BigDecimal("1000000"), "USD", Side.BUY, 30
        );

        var response = service.createRfq(req);

        assertThat(response.rfqId()).isNotNull();
        assertThat(response.status()).isEqualTo("CREATED");

        // Entity row present
        assertThat(rfqRepository.findByIdempotencyKey("it-key-001")).isPresent();

        // Outbox row present and payload is Avro (starts with Confluent magic byte 0x00)
        var pending = outboxRepository.fetchPendingSkipLocked(10);
        assertThat(pending).anyMatch(e ->
            e.aggregateId().equals(response.rfqId().toString()) &&
            e.status() == OutboxStatus.PENDING &&
            e.payload().length > 5 &&
            e.payload()[0] == 0x00   // Confluent magic byte
        );
    }

    @Test
    void createRfq_idempotency_singleRowOnReplay() {
        var req = new CreateRfqRequest(
            "it-key-002", "user-bob", "desk-fx-1",
            "EUR/USD-SPOT", "EUR/USD",
            new BigDecimal("500000"), "USD", Side.SELL, 30
        );

        var first  = service.createRfq(req);
        var second = service.createRfq(req); // replay

        assertThat(second.rfqId()).isEqualTo(first.rfqId());

        // Still only one row in rfq_versions for this key
        long count = rfqRepository.findByIdempotencyKey("it-key-002")
            .stream().count();
        assertThat(count).isEqualTo(1);
    }
}
